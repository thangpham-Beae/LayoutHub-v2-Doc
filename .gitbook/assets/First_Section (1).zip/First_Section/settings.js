[
    {
        name: 'first',
        label: 'The first setting',
        type: 'text',
        value: 'The default value'
    }
]