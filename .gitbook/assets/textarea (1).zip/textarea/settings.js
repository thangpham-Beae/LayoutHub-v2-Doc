[
    {
        name: 'text',
        label: 'My Text',
        type: 'textarea',
        value: 'Default content of textarea'
    }
]