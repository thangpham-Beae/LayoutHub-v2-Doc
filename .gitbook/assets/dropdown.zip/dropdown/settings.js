[
    {
        name: 'drop',
        label: 'Select value',
        type: 'dropdown',
        value: 'two',
        options: {
	        'one': 'Value 1',
	        'two': 'Value 2',
	        'three': 'Value 3'
        }
    }
]