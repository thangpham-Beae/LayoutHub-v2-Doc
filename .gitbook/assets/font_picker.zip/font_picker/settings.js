[
    {
        name: 'my_font',
        label: 'Select font',
        type: 'font',
        value: 'Open Sans'
    }
]