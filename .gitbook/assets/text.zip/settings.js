[
    {
        name: 'title',
        label: 'My Title',
        type: 'text',
        value: 'Default '
    },
    {
        name: 'field_disabled',
        label: 'field_disabled',
        type: 'text',
        value: 'Disabled value',
        options: {
	        disabled: true
        }
    },
    {
        name: 'field_readonly',
        label: 'field_readonly',
        type: 'text',
        value: 'Readonly value',
        options: {
	        readonly: true
        }
    }
]