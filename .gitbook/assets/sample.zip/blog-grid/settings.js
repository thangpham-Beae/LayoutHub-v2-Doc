[
	{
		name  : 'title',
		label : 'Title',
		type  : 'text',
		value : 'The popular <span>article</span>'
	},
	{
		name  : 'des',
		label : 'Description',
		type  : 'textarea',
		value : ''
	},
	{
		name  : 'title_full',
		label : 'Show blog title',
		type  : 'dropdown',
		value : 'full_text',
		options : {
			'ellipsis'  : 'Short title',
			'full_text' : 'Full title'
		}
	},
	{
		name  : 'read_more',
		label : 'Label button more',
		type  : 'text',
		value : 'Read More'
	},
	{
		name  : 'blog_picker',
		label : 'Blog picker',
		type  : 'picker',
		value : [],
		"options" :{
			"button_text" : 'Browse blog',
			"multiple"    : false,
			"search"      : true,
			"type"		  : 'blog',
			"title"       : 'Pick a blog',
			"layout"	  : 'list',
			"default"	  : ''
		}
	},
	{
		name: "by",
		label: "Label by",
		type: "text",
		value: "By"
	}
]
