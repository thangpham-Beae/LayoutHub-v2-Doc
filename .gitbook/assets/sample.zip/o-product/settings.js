[
	{
    tab_name: "General",
    settings: [
			{
				name  : 'title',
				label : 'Title',
				type  : 'text',
				value : 'Boots for <span>her</span>'
			},
			{
				name  : 'des',
				label : 'Description',
				type  : 'textarea',
				value : 'Contrary to popular belief, Lorem Ipsum is not simply random text'
			},
			{
				name  : 'limit',
				label : 'Number of item to show',
				type  : 'number_slider',
				value : 8,
				options : {
					min : 2,
					max : 12
				}
			},
			{
        type: "toggle",
        name: "show_badge",
        label: "Promote label",
        value: "yes"
      },
			{
				name  : 'name_product',
				label : 'Show name of product',
				type  : 'dropdown',
				value : 'ellipsis',
				options : {
					'ellipsis' : 'Short title',
					'full'     : 'Full title'
				}
			},
			{
				name   : 'image_size',
				label  : 'Product size',
				type   : 'text',
				description : 'Set the image size:<br/>"icon:32x32",<br/>"small: 50x50",<br/>"compact: 160x160",<br/>"medium: 240x240",<br/>"large: 480x480",<br/>"grande: 600x600",<br/>"master largest image: 2048x",<br/>"full" or "370x370_crop_center"',
				value  : '540x720_crop_center'
			},
			{
        name    : 'collection',
        label   : 'Select collection',
        type    : 'picker',
        value   : [],
        "options" : {
          "button_text" : 'Browse Collection',
          "multiple"    : false,
          "search"      : true,
          "type"        : 'collection',
          "title"       : 'Pick a collection',
          "layout"    : 'list',
          "default"   : ''
        }
      },
			{
            "type": "toggle",
            "label": "Show rating",
            "name": "use_rating",
            "value": "no"
    	}
		]
	},
	{
    "tab_name": "Set swatch layout",
    "settings": [
      {
        name: "use_swatch",
        label: "Use swatch",
        type: "toggle",
        value: "yes"
      },
      {
        "name": "group_variants",
        "label": "Variants group",
        "type": "group",
        "value": [
          {
            "swatch_name": "Color",
            "swatch_style": "circle",
            "is_swatch_image": "yes",
            "show_value": "no"
          },
          {
            "swatch_name": "Size",
            "swatch_style": "tag"
          },
          {
            "swatch_name": "Material",
            "swatch_style": "tag"
          }
        ],
        "options": {
          "add_text": "Add new variant layout"
        },
        "params": [
          {
            "name": "swatch_name",
            "type": "text",
            "label": "Product option name",
            "description": "Fill in your product option"
          },
          {
            "name": "swatch_style",
            "label": "Swatch type",
            "description": "Select variant layout for variant name above",
            "type": "dropdown",
            "value": "tag",
            "options": {
              "circle": "Circle",
              "square": "Square",
              "tag": "Tag"
            }
          },
          {
            "name": "is_swatch_image",
            "label": "Is swatch color(image)",
            "type": "toggle",
            "value": "no",
            "relation": {
              "parent": "swatch_style",
              "show_when": "circle,square"
            }
          },
          {
            "name": "show_value",
            "label": "Show variant name",
            "type": "toggle",
            "value": "no",
            "relation": {
              "parent": "swatch_style",
              "show_when": "circle,square"
            }
          }
        ]
      }
    ]
  },
	{
    tab_name: "Change Text",
    settings: [
      {
        type: "text",
        label: "Sold out badge text",
        name: "trans_soldout_text",
        value: "Sold out"
      },
      {
        type: "text",
        label: "New badge text",
        name: "trans_new_text",
        value: "New"
      },
      {
        type: "text",
        label: "Add cart text",
        name: "addcart_text",
        value: "Add to cart"
      },
      {
        type: "text",
        label: "Quick shop text",
        name: "quickshop_text",
        value: "Quick shop"
      },
      {
        type: "text",
        label: "Sold out text",
        name: "soldout_text",
        value: "Sold out"
      },
			{
        type: "text",
        label: "Unavailable text",
        name: "unavailable_text",
        value: "Unavailable"
      },
      {
        type: "text",
        label: "Quick view text",
        name: "quickview_text",
        value: "Quick view"
      },
      {
        type: "text",
        label: "View all text",
        name: "viewall_text",
        value: "View All Products"
      }
    ]
  }
]
