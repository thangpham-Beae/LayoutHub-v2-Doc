[
  {
    tab_name: "General",
    settings: [
        {
          name: "title",
          label: "Title",
          type: "text",
          value: "Review of <span>customer</span>"
        },
        {
          name: 'loop',
          label: 'Slide loop',
          type: 'toggle',
          value: 'no'
        },
        {
          name: 'use_auto_rotate',
          label: 'Slide auto play',
          type: 'toggle',
          value: 'no'
        },
        {
            name: 'nav_delay',
            label: 'Slide change every (s)',
            description : 'Only works when Slide auto play: YES',
            type  : 'number_slider',
    				value : 7,
    				options : {
    					min : 1,
    					max : 12,
              step: 0.1
    				},
            relation: {
                parent: "use_auto_rotate",
                show_when: "yes"
            },
        },
        {
            name: 'image',
            label: 'Image banner',
            type: 'single_image',
            value: {
    	        src: '%URL%assets/images/img.png',
    	        alt: 'banner',
              width: '100%'
            }
        }
    ]
  },
  {
		'tab_name' : 'Slides',
		'settings' : [
      {
        name: 'sliders',
        label: 'Slides',
        type: 'group',
        value: [
          {
            content_text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type .",
            vendor: "Ms.Cady Luii",

          },
          {
            content_text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type .",
            vendor: "John Shi",

          }
        ],
        options: {
            add_text: 'Add new slide'
        },
        params: [
            {
              name: 'content_text',
              type: 'text',
              label: "Content text",
              value: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam'
            },

            {
              name: "vendor",
              type: "text",
              label:"Vendor",
              value: "John Doe"
            }
          ]
      }
    ]
  }
]
