[
	{
    tab_name: "General",
    settings: [
			{
				name  : 'title',
				label : 'Title',
				type  : 'text',
				value : 'HOT <span>TREND</span>'
			},
			{
				name  : 'limit',
				label : 'Number of item to show',
				type  : 'number_slider',
				value : 10,
				options : {
					min : 2,
					max : 12
				}
			},
			{
				name  : 'auto',
				label : 'Product auto play',
				type  : 'toggle',
				value : 'no'
			},
			{
				name  : 'time',
				label : 'Slide change every (s)',
				description: 'Only works when Product auto play: YES',
				type  : 'number_slider',
				value : 5,
				options : {
					min : 1,
					max : 12,
					step: 0.1
				},
				relation: {
					parent: "auto",
					show_when: "yes"
				}
			},
			{
        type: "toggle",
        name: "show_badge",
        label: "Promote label",
        value: "yes"
      },
			{
				name  : 'name_product',
				label : 'Show name of product',
				type  : 'dropdown',
				value : 'ellipsis',
				options : {
					'ellipsis' : 'Short title',
					'full'     : 'Full title'
				}
			},
			{
				name   : 'image_size',
				label  : 'Product image size',
				type   : 'text',
				description : 'Set the image size:<br/>"icon:32x32",<br/>"small: 50x50",<br/>"compact: 160x160",<br/>"medium: 240x240",<br/>"large: 480x480",<br/>"grande: 600x600",<br/>"master largest image: 2048x",<br/>"full" or "370x370_crop_center"',
				value  : '370x494_crop_center'
			},
			{
				name   : 'collections',
				label  : 'Collections',
				type   : 'picker',
				value  : [],
				"options" : {
					"button_text" : 'Browse Collections',
					"multiple"	  : true,
					"search"	  : true,
					"type"		  : 'collection',
					"title"		  : 'Pick collections',
					"layout"	  : 'list',
					"default"	  : ''
				}
			},
			{
            "type": "toggle",
            "label": "Show rating",
            "name": "use_rating",
            "value": ""
      },
			{
	        name: 'banner',
	        label: 'Image banner',
	        type: 'single_image',
	        value: {
		        src: '%URL%assets/images/banner.png',
		        alt: 'banner',
						width: '100%'
	        }
	    }
		]
	},
	{
    tab_name: "Change Text",
    settings: [
      {
        type: "text",
        label: "Label new",
        name: "new_text",
        value: "New"
      },
      {
        type: "text",
        label: "Label sold out",
        name: "soldout_text",
        value: "Sold out"
      }
    ]
  }
]
