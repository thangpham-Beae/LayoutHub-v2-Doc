[
  {
    tab_name: "General",
    settings: [
      {
    		name  : 'title',
    		label : 'Title',
    		type  : 'text',
    		value : 'Choose a <span>category</span>'
    	},
    	{
    		name  : 'des',
    		label : 'Description',
    		type  : 'textarea',
    		value : 'It is a long established fact that a reader will be distracted'
    	},
    	{
    		name  : 'viewall',
    		label : 'Label view all',
    		type  : 'text',
    		value : 'View All'
    	},
      {
        name: 'loop',
        label: 'Slide loop',
        type: 'toggle',
        value: 'yes'
      },

      {
        name: 'use_auto_rotate',
        label: 'Slide auto play',
        type: 'toggle',
        value: 'no'
      },
      {
          name: 'nav_delay',
          label: 'Slide change every (s)',
          description : 'Only works when Slide auto play: YES',
          type  : 'number_slider',
  				value : 5,
  				options : {
  					min : 1,
  					max : 12,
            step: 0.1
  				},
          relation: {
              parent: "use_auto_rotate",
              show_when: "yes"
          },
      }
    ]
  },
  {
		'tab_name' : 'Slides',
		'settings' : [
      {
        name: 'group_slide',
        label: 'Slides',
        type: 'group',
        value: [
          {
            collection: [],
            img: {
              src: "%URL%assets/images/cate-1.png",
              alt: "collection"
            }
          },
          {
            collection: [],
            img: {
              src: "%URL%assets/images/cate-2.png",
              alt: "collection"
            }
          },
          {
            collection: [],
            img: {
              src: "%URL%assets/images/cate-3.png",
              alt: "collection"
            }
          },
          {
            collection: [],
            img: {
              src: "%URL%assets/images/cate-4.png",
              alt: "collection"
            }
          },
          {
            collection: [],
            img: {
              src: "%URL%assets/images/cate-5.png",
              alt: "collection"
            }
          },
          {
            collection: [],
            img: {
              src: "%URL%assets/images/cate-3.png",
              alt: "collection"
            }
          }
        ],
        options: {
	    	    add_text: 'Add new slide'
        },
        params: [
          {
              name: 'collection',
              label: 'Select collection',
              type: 'picker',
              value: [],
              "options": {
                  "button_text": 'Browse collection',
                  "multiple": false,
                  "search": true,
                  "type": 'collection',
                  "title": 'Collection',
                  "layout": 'list',
                  "default": 'main-menu'
              }
          },
          {
            type: "single_image",
            label: "Collection image",
            name: "img"
          }
        ]
      }
    ]
  }
]
