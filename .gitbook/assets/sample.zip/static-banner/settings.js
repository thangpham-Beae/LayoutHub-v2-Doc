[
  {
    name: 'title',
    label: 'Title',
    type: 'text',
    value: 'COLLECTION',

  },
  {
    name: 'subtitle',
    label: 'Subtitle',
    type: 'text',
    value: 'COLORFUL'
  },
  {
    name: 'button',
    label: 'Button',
    type: 'link',
    value: 'Go To Shop',
    value: {
      href: '#',
      text: 'Go To Shop'
    }
  },
  {
    type: "single_image",
    label: "Background image",
    name: "img",
    value: "",
    value: {
      src: '%URL%assets/images/img-banner.png',
      alt: 'banner',
      width: '100%'
    }
  }
]
