[
  {
    tab_name: "General",
    settings: [
      {
        name: 'loop',
        label: 'Slide loop',
        type: 'toggle',
        value: 'yes'
      },

      {
        name: 'use_auto_rotate',
        label: 'Slide auto play',
        type: 'toggle',
        value: 'no'
      },
      {
          name: 'nav_delay',
          label: 'Slide change every (s)',
          description : 'Only works when Slide auto play: YES',
          type  : 'number_slider',
  				value : 5,
  				options : {
  					min : 1,
  					max : 12,
            step: 0.1
  				},
          relation: {
              parent: "use_auto_rotate",
              show_when: "yes"
          },
      },
      {
        name: 'use_dots',
        label: 'Slide dots',
        type: 'toggle',
        value: 'yes'
      },

    ]
  },
  {
		'tab_name' : 'Slides',
		'settings' : [
      {
        name: 'group_slide',
        label: 'Slides',
        type: 'group',
        value: [
          {
              headding_text: "What <span>She</span> Really Wants?",
              subheadding_text: "Vivamus et velit lobortis sem pharetra lacinia",
              bg_slider: '#ffffff url(%URL%assets/images/slider_img_1.png) center center/cover no-repeat scroll',
              button: {
      	        href: '#',
      	        text: 'Discover Now'
              },
              overlay: 'no'
          },
          {
              headding_text: "<span>Beauty</span> Of The Night",
              subheadding_text: "Vivamus et velit lobortis sem pharetra lacinia",
              bg_slider: '#ffffff url(%URL%assets/images/slider_img_2.png) center center/cover no-repeat scroll',
              button: {
      	        href: '#',
      	        text: 'Discover Now'
              },
              overlay: 'no'
          }
        ],
        options: {
	    	    add_text: 'Add new slide'
        },
        params: [
  	        {
  		        name: 'headding_text',
  		        type: 'text',
  		        label: 'Title'
  	        },
  	        {
  		        name: 'subheadding_text',
  		        type: 'text',
  		        label: 'Subtitle'
  	        },
            {
              name: "button",
              type: "link",
              label:"Button",
            },
  					{
  						name  : 'overlay',
  						label : 'Overlay',
  						type  : 'toggle'
  					},
            {
                name: 'bg_slider',
                label: 'Set background',
                type: 'css_background',
                value: {
        	        color: '#ffffff',
        	        image: '%URL%assets/images/slide_img_1.svg',
        	        position: 'center center',
        	        repeat: 'no-repeat',
        	        size: 'cover'
                }
            }
        ]
      }
    ]
  }
]
