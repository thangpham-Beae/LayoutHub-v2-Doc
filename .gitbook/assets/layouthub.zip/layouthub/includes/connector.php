<?php
/**
 * LayoutHub Connector
 *
 * @package LayoutHub
 * @since   1.0
 */

defined( 'ABSPATH' ) || exit;

global $layouthub;

$connect_session = $layouthub->fn->get_connect_session();

if (
	$connect_session === null
) return;
			
?>
<script>
	
(function($) {
	
	'use strict';
	
	let conn = (d) => {
			
			let method = '',
				url = '',
				ops = {
				    method: '',
				    withCredentials: true,
				    credentials: 'same-origin'
				};
				
			if (
				d.data !== undefined &&
				typeof d.data == 'string' &&
				d.method == 'get'
			) {
				ops.method = 'GET'
				url = e.data.data;
			} else {
				ops.method = 'POST';
				url = '<?php echo admin_url( 'admin-ajax.php' ); ?>';
				
				let data = d.data && typeof d.data == 'object' ? d.data : {},
					dataURLtoBlob = (dataurl) => {
		
					    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
					        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
					    while(n--){
					        u8arr[n] = bstr.charCodeAt(n);
					    }
					    
					    return new Blob([u8arr], {type:mime});
					    
					},
					formData = new FormData();
					
				data.nonce = '<?php echo wp_create_nonce('ajax_connector_nonce'); ?>';
				data.hub_action = data.action;
				data.action = 'layouthub_ajax_connector';
				
				Object.keys(data).map(function(a) {
					
					let val = data[a];
					
					if (data[a].constructor === [].constructor) {
						val = JSON.stringify(val);
					} else if (data[a].constructor === ({}).constructor ) {
						if (
							val.name !== undefined &&
							val.type !== undefined &&
							val.data !== undefined
						) {
							if (val.is == 'blob') {
								val =  new Blob([val.data], {type: val.type}); 
							} else if (val.is == 'dataurl') {
								val =  new File(
									[dataURLtoBlob(val.data)], 
									val.name
								);
							} else {
								val = JSON.stringify(val);
							}
						} else {
							val = JSON.stringify(val);
						}
					};
					
					formData.append(a, val);
						
				});
				
				ops.body = formData;
				
			};
			
			fetch( url, ops )
			.then((res) => {
				return (ops.method == 'GET' ? res.text() : res.json());
			})
			.then((res) => {
				
				if (
					res &&
					res.connect_success === false
				) {
					
					if (
						res.reconnect === true &&
						res.url !== undefined &&
						confirm(res.message)
					) {
						app_window.postMessage({
							action: 'platform_connector',
							sub_action: 'login',
							data: {
								url: res.url
							}
						}, '<?php echo $layouthub->app_endpoint; ?>');
					};
					
					if (res.reconnect === undefined)
						alert(res.message);
						
					return;
					
				};
				
				if (typeof d.callback == 'function')
					return d.callback(res);
				
				app_window.postMessage({
					action: 'platform_connector',
					sub_action: 'ajax_connector',
					event_id: d.event_id,
					data: res
				}, '<?php echo $layouthub->app_endpoint; ?>');
				
			})
			.catch(() => {
				
				if (typeof d.callback == 'function')
					return d.callback(null);
					
				app_window.postMessage({
					action: 'platform_connector',
					sub_action: 'ajax_connector',
					event_id: d.event_id,
					data: null
				}, '<?php echo $layouthub->app_endpoint; ?>');
				
			});
			
		},
	
		app_window = null,
		
		get_init = (d) => {
	
			conn({
				data: {
					action: 'connector_init',
					page_id: d.page_id,
					connect_session: d.connect_session
				},
				callback: (res) => {
					
					if (res !== null && res.success === true) {
						
						if (
							app_window === null ||
							app_window.closed === true
						) {
							return;
						};
						
						app_window.postMessage({
							action: 'platform_connector',
							sub_action: 'ready',
							data: {
								version: '<?php echo LH_VER; ?>',
								cfg : res.data
							}
						}, '<?php echo $layouthub->app_endpoint; ?>');
						
					} else {
						alert('Error while initializing app, please contact support for more detail.');
					}
					
				}
			});
		};
	
		window.addEventListener('message', (e) => {

			if (
				(
					e.origin.match(/^https?\:\/\/(app|dev|beta)\.layouthub\.com$/) !== null
					//|| '<?php echo $layouthub->app_endpoint; ?>'.indexOf(e.origin) === 0
				) &&
				e.data !== undefined &&
				e.data.connect_session === '<?php echo $connect_session; ?>'
			) {
				
				app_window = e.source;
				
				if (
					e.data &&
					e.data.action == "ajax_connector"
				) {
					return conn(e.data);
				} else if (
					e.data &&
					e.data.action == "init_editor"
				) {
					return get_init(e.data);
				}
			}
			
		});
	
	$('button#layouthub-connect-app').on('click', function(e) {
		app_window = window.open(this.getAttribute('data-connect-url'));
		e.preventDefault();
	});

	window.onunload = function () {
	    alert("Do you really want to close?");
	};
	
})(jQuery);
	
</script>