<?php
/**
 * LayoutHub Backend
 *
 * @package LayoutHub
 * @since   1.0
 */

defined( 'ABSPATH' ) || exit;

class LayoutHub_Backend {
	
	protected $lh;
	protected $page;
	
	public function __construct($lh) {
		
		$this->lh = $lh;
		$this->page = esc_attr(isset($_GET['page']) ? $_GET['page'] : '');
		
		if (!defined('LH_ADMIN'))
			define('LH_ADMIN', true);
		
		$this->roles();
		
		add_action( 'admin_init', array($this, 'admin_init'), 9999 );
		add_action( 'admin_bar_menu', array($this, 'admin_bar_menu'), 999 );
		add_action( 'admin_footer', array($this, 'admin_footer'), 9999 );
		
		add_action( 'admin_menu', array($this, 'menu_page') );
		add_action( 'wp_ajax_layouthub_install_theme', array($this, 'ajax_layouthub_install_theme') );
		add_action( 'wp_ajax_layouthub_save_theme_settings', array($this, 'ajax_layouthub_save_theme_settings') );
		add_action( 'admin_enqueue_scripts', array($this, 'enqueue_scripts'), 9999);
		add_filter( 'script_loader_tag', array($this, 'script_loader_tag'), 10, 3 );
		add_filter( 'upload_mimes', array($this, 'upload_mime_types') );
		
		add_action( 'wp_ajax_layouthub_ajax_connector', array($this, 'ajax_connector') );
				
	}
	
	public function admin_init() {
		
		global $post;
		
		if (get_option('layouthub_do_activation_redirect', false)) {

		    delete_option('layouthub_do_activation_redirect');
	
		    if (!isset($_GET['activate-multi'])) {
	            wp_redirect("admin.php?page=layouthub");
	            exit; 
	        }
	    }
	    
	    $this->disable_blocks();
	    
		if (
			!isset($_GET['page']) ||
			$_GET['page'] != 'layouthub'
		) return;
		
	    if (isset($_GET['page']) && $_GET['page'] == 'layouthub') {
	    	header('Referrer-Policy: no-referrer-when-downgrade');
	    }
		
		if(
			isset($_GET['session_editing']) &&
			isset($_GET['nonce'])
		) {
			
			$checknonce = get_option('lh_safe_login_redirect', true);
			
			if ($checknonce == $_GET['nonce']) {
				
				$redirect = strrev($_GET['session_editing']);
				$redirect = base64_decode($redirect);
				$redirect = urldecode($redirect);
				$redirect = trim($redirect);
			?>
				<script>
					window.location.href = '<?php echo $redirect; ?>';
				</script>
			<?php	
			} else {
				wp_die(
					'Invalid nonce token. <a href="'.admin_url('admin.php?page=layouthub').'">Go Back</a>'
				);
			}
			
			exit;
			
		}
				
	}
	
	public function admin_footer() {
		
		global $post;
		
		include(dirname(__FILE__).DS.'connector.php');
		
		?>
		<script>
			
		<?php
			if (
				isset($post) &&
				$post->post_type = 'page'
			) {
		?>
			(function($) {
				let add_btn = () => {
					let header_toolbar = document.querySelectorAll('div.edit-post-header-toolbar');
					if (header_toolbar[0] !== undefined) {
						let lhbtn = document.createElement('a');
						lhbtn.innerHTML = '<img style="vertical-align: middle;" src="<?php echo $this->lh->assets_url; ?>images/icon.svg" alt=""> Edit with LayoutHub';
						lhbtn.className = 'button button-primary button-large';
						lhbtn.href = '<?php echo admin_url('post.php?post='.$post->ID.'&action=edit&layouthub_action=enable_editor'); ?>';
						header_toolbar[0].appendChild(lhbtn)
					} else {
						window.onload = add_btn;
					}
				};
				$(document).on('ready', () => {
					setTimeout(add_btn, 1);
				});
			})(jQuery);
		<?php } ?>	
		
		</script>
		<?php
	}
	
	public function disable_blocks() {
		
		if (
			isset($_GET['action']) &&
			isset($_GET['post']) &&
			$_GET['action'] == 'edit'
		) {
			
			if (
				isset($_GET['layouthub_action'])
			) {
				
				if (
					$_GET['layouthub_action'] == 'enable_editor'
				) {
					if( get_post_meta( $_GET['post'], '_wp_page_template' ) === false )
						add_post_meta( $_GET['post'], '_wp_page_template' , 'templates/layouthub.php' );
					else 
						update_post_meta( $_GET['post'] , '_wp_page_template' , 'templates/layouthub.php' );
				} else if (
					$_GET['layouthub_action'] == 'disable_editor'
				) {
					delete_post_meta($_GET['post'], '_wp_page_template' );
				}
				
			}
			
			$page_template = get_page_template_slug($_GET['post']);
			
			if (
				isset($page_template) &&
				$page_template == 'templates/layouthub.php'
			) {
				
				add_filter( 'use_block_editor_for_post', '__return_false', 666 );
				remove_all_filters('edit_form_after_title');
				add_filter( 'edit_form_after_title', array($this, 'hook_after_title'), 9999 );
				
			} else {
				add_filter( 'edit_form_after_title', array($this, 'hook_after_title_classic'), 9999 );	
			}
			
		}
	}
	
	public function hook_after_title() {
		
		global $post;
		
		$switch_back = admin_url('post.php?post='.$post->ID.'&action=edit&layouthub_action=disable_editor');
		$connect_url = $this->lh->app_endpoint.'&page-id='.$post->ID.'&connect_token='.$this->lh->fn->get_connect_token();
		
	?>
		<style type="text/css">
			#post-body-content>*:not(#titlediv):not(#connect-layouthub) {
				display: none !important;
			}
			#connect-layouthub {
				display: inline-block;
			    width: 100%;
			    background: #fff;
			    border: 1px solid #ccd0d4;
			    box-shadow: 0 0 0 transparent;
			    text-align: center;
			    padding: 35px 0 20px;
			    margin-top: 50px;
			}
			#connect-layouthub button.button-large{
				padding: 5px 24px;
				font-size: 14px;
				margin: 20px 0 10px;
			}
		</style>
		<div id="connect-layouthub">
			<h1><?php _e('Edit with LayoutHub', 'layouthub'); ?>!</h1>
			<p>
				<?php _e('Please do not logout or close this window<br>While you are editing this page on the LayoutHub App', 'layouthub'); ?>.
			</p>
			<p>
				<button id="layouthub-connect-app" data-connect-url="<?php echo esc_url($connect_url); ?>" class="button button-primary button-large">
					<img style="vertical-align: middle;" src="<?php echo $this->lh->assets_url; ?>images/icon.svg" alt=""> 	
					<?php _e('Connect to LayoutHub App', 'layouthub'); ?>
				</button>
			</p>
			<p>
				<a class="button" href="<?php echo esc_url($switch_back); ?>">
					&larr; <?php _e('Switch back to WP Editor', 'layouthub'); ?>
				</a>
			</p>
			<p style="text-align: center;margin-top: 50px;">
				<a href="<?php echo admin_url('admin.php?page=layouthub#settings'); ?>" target=_blank><?php 
					_e('LayoutHub settings', 'layouthub'); 
				?></a>
				&nbsp;|&nbsp;
				<a href="<?php echo admin_url('admin.php?page=layouthub#terms'); ?>" target=_blank><?php 
					_e('Terms of service', 'layouthub'); 
				?></a>
			</p>
		</div>
		
	<?php
			
	}
	
	public function hook_after_title_classic() {
		global $post;
		$enable_link = admin_url('post.php?post='.$post->ID.'&action=edit&layouthub_action=enable_editor');
		?>
		<div>
			<a href="<?php echo esc_url($enable_link); ?>" class="button button-primary button-large" style="padding: 5px 24px;font-size: 14px;">
				<img style="vertical-align: middle;" src="<?php echo $this->lh->assets_url; ?>images/icon.svg" alt="">
				<?php _e('Edit with LayoutHub', 'layouthub'); ?>
			</a>
		</div>
		<?php
	}
	
	public function admin_bar_menu() {
		
		global $wp_admin_bar, $post;
		
		if (
			!isset($post) ||
			!isset($post->post_type) ||
			$post->post_type != 'page'
		) return;
		
		$wp_admin_bar->add_menu(array(
			"id" => "LayoutHub",
			"title" => '<img style="vertical-align: middle;" src="'.$this->lh->assets_url.'images/icon.svg" alt=""> Edit with LayoutHub',
			"href" => admin_url('post.php?post='.$post->ID.'&action=edit&layouthub_action=enable_editor')
		));
		
		
	}
	
	private function roles() {
		
		$role = get_role('administrator');
		
		$role->add_cap('layouthub_access');
		$role->add_cap('layouthub_can_upload');
		
	}
	
	public function enqueue_scripts() {
		
		global $post;
		
		if ($this->page == 'layouthub') {
			
			wp_enqueue_media();
			wp_register_style('layouthub-backend', $this->lh->assets_url.'css/backend.css', false, $this->lh->version);
			wp_register_script('layouthub-backend', $this->lh->assets_url.'js/backend.js', false, $this->lh->version);
			wp_enqueue_style('layouthub-backend');
			wp_enqueue_script('layouthub-backend');
			
			$data = array(
				"nonce" =>  wp_create_nonce('layouthub_wp_backend'),
				"upload_dir" => wp_upload_dir()
			);
			
			foreach(
				array(
					"developer", 
					"global_fullpage", 
					"logo", 
					"color", 
					"font_family", 
					"title_font_family", 
					"font_size", 
					"custom_css", 
					"custom_js"
				) as $name 
			) {
				 $data[$name] = get_option("layouthub_".$name);
			}
			
			wp_localize_script('layouthub-backend', 'layouthub_data', $data);
			
		}
		
	}
	
	public function script_loader_tag( $tag, $handle, $source ) {
		
	    if ( 'layouthub-backend' === $handle ) {
	        $tag = '<script type="module" src="' . $source . '"></script>';
	    }
	
	    return $tag;
	}
	
	public function menu_page() {
        
        global $wpdb;
        
        add_menu_page( 
            	'LayoutHub',
                'LayoutHub',
                'layouthub_access',
                'layouthub',
                array($this, 'admin_page'),
                $this->lh->assets_url . 'images/icon.svg',
            90
        );
        
    }
	
	public function upload_mime_types( $mimes ) {
		
		$mimes['ttf'] = 'application/x-font-ttf';
		$mimes['woff'] = 'application/woff';
		$mimes['woff2'] = 'application/woff2';
		 
		return $mimes;
	
	}
	
	public function ajax_layouthub_install_theme() {
		
		global $layouthub;
		
		header("content-type: application/json");
		
		if (
			!wp_verify_nonce($_POST['nonce'], 'layouthub_wp_backend')
		) wp_die('Invalid nonce');
		
		$theme_root = get_theme_root();
		$theme_root = str_replace('/', DS, $theme_root);
		
		if (is_dir($theme_root.DS.'layouthub')) {
			switch_theme('layouthub');
		} else {
			
			require_once(ABSPATH .'/wp-admin/includes/file.php');

			global $wp_filesystem;
			
			if ( ! $filesystem ) {
			  WP_Filesystem();
			    if ( ! $wp_filesystem ) {
				    echo json_encode(array(
						"success" => false,
						"msg" => "wp_filesystem cannot be initialized"
					));
					exit;
			    }
			}
			
			if (!unzip_file(LH_PATH.DS.'install'.DS.'layouthub.zip', $theme_root)) {
				echo json_encode(array(
					"success" => false,
					"msg" => "Could not unzip theme on your server"
				));
				exit;
			}
			
			switch_theme('layouthub');
			
		}
		
		if (
			!isset($_POST['slug']) ||
			!isset($_POST['pages'])
		) wp_die('Missing parameters');
		
		$slug = $_POST['slug'];
		$home = $_POST['home_page'];
		$pages = $_POST['pages'];
		
		$theme_data = $layouthub->fn->post(
			'http://localhost/LH/layouthub/DEV/host.php', 
			array(
				"task" => "get_theme",
				"slug" => $slug,
				"pages" => json_encode(array_keys($pages))
			)
		);
	
		$theme_data = json_decode($theme_data, true);
		$hub_path = $layouthub->upload_path;
		
		$yy = date('Y', time());
		$yymm = date('Y', time()).DS.date('m', time());
		
		if (
			(
				!is_dir($hub_path) &&
				!mkdir($hub_path, 0755)
			) ||
			(
				!is_dir($hub_path.DS.$yy) &&
				!mkdir($hub_path.DS.$yy, 0755)
			) ||
			(
				!is_dir($hub_path.DS.$yymm) &&
				!mkdir($hub_path.DS.$yymm, 0755)
			)
		) {
			echo json_encode(array(
				"success" => false,
				"msg" => "Could not create folder"
			));
			exit;
		}
		
		$tpath = $yymm.DS.$theme_data['id'];

		/*
		* Storage header
		*/
		
		if (
			is_array($theme_data['header']) &&
			$this->lh->fn->create_hub_files(
				$hub_path.$tpath.'_header', 
				$theme_data['header']
			)
		) {
			update_option('layouthub-header', urlencode($tpath.'_header'));
			update_option( 'layouthub-header-time', time());
		} else {
			echo json_encode(array(
				"success" => false,
				"msg" => "Could not create header"
			));
			wp_die();
		};
		/*
		* Storage footer
		*/
		if (
			is_array($theme_data['footer']) &&
			$this->lh->fn->create_hub_files(
				$hub_path.$tpath.'_footer', 
				$theme_data['footer']
			)
		) {
			update_option('layouthub-footer', urlencode($tpath.'_footer'));
			update_option( 'layouthub-footer-time', time());
		} else {
			echo json_encode(array(
				"success" => false,
				"msg" => "Could not create footer"
			));
			wp_die();
		}
		/*
		* Storage pages
		*/
		if (
			is_array($theme_data['pages']) &&
			count($theme_data['pages']) > 0
		) {
			
			$menu_name = 'LayoutHub';
			$menu_exits = wp_get_nav_menu_object( $menu_name );

			if (!$menu_exits) {
			    $menu_id = wp_create_nav_menu($menu_name);
			} else $menu_id = $menu_exits->term_id;
			
			$this->lh->fn->clear_menu($menu_id);
			
			foreach ($pages as $page_id => $nav) {
				
				foreach ($theme_data['pages'] as $p) {
					if ($p['id'] == $page_id)
						$page = $p;
				}
				
				if (
					$this->lh->fn->create_hub_files(
						$hub_path.$tpath.'_'.$page['id'], 
						$page
					)
				) {
					
					$new_page = wp_insert_post(array(
						"ID" => 0,
						"post_title" => $page['name'],
						"post_content" => "",
						"post_status" => "publish",
						"post_type" => "page"
					));
					
					if (is_wp_error($new_page)) {
						wp_die($new_page->get_error_message());
					}
					
					update_post_meta($new_page, 'layouthub', urlencode($tpath.'_'.$page['id']));
					update_post_meta($new_page, 'layouthub-time', time());
					
					update_post_meta($new_page, '_wp_page_template', 'templates/layouthub.php');
					
					if ($nav == 'true') {
						wp_update_nav_menu_item($menu_id, 0, 
							array(
						        'menu-item-title' => $page['name'],
						        'menu-item-object' => 'page',
						        'menu-item-object-id' => $new_page,
						        'menu-item-type' => 'post_type',
						        'menu-item-status' => 'publish'
					        )
					    );
					}
					
					if ($home == $page['id']) {
						update_option('show_on_front', 'page', true);
						update_option('page_on_front', $new_page, true);
					}
					
				} else {
					echo json_encode(array(
						"success" => false,
						"msg" => "Could not create page ".$page['name']
					));
					wp_die();
				}
			}
			
		}
		
		if (isset($theme_data['settings'])) {
			if (isset($theme_data['settings']['custom_css'])) {
				$theme_data['settings']['custom_css'] = base64_encode(urlencode($theme_data['settings']['custom_css']));
			}
			$layouthub->fn->process_save_theme_settings($theme_data['settings']);
		}
		
		echo json_encode(array(
			"success" => true ,
			"url" => site_url()
		));
		wp_die();
	}
	
	public function ajax_layouthub_save_theme_settings() {
		
		global $layouthub;
		
		header("content-type: application/json");
				
		if (
			!wp_verify_nonce($_POST['nonce'], 'layouthub_wp_backend')
		) {
			wp_die('Invalid nonce');
		}
		
		$res = array("errors" => array(), "logo" => get_option("layouthub_logo"));
		
		$hub_dir = $layouthub->upload_path;
		$hub_url = $layouthub->upload_url;
		
		$current_logo = get_option('layouthub_logo');
		
		if (
			!is_dir($hub_dir) &&
			!mkdir($hub_path, 0755)
		) {
			array_push($res['errors'], "Error, could not create folder");
		}
		
		if (
			isset($_POST['task']) &&
			$_POST['task'] == 'delete_logo'
		) {
			if (
				$current_logo &&
				is_file($hub_dir.$current_logo)
			) {
				unlink($hub_dir.$current_logo);
			}
			delete_option('layouthub_logo');
			unset($res['logo']);
			echo json_encode($res);
			exit;
		}
		
		if (
			isset($_FILES['logo'])
		) {
			
			if (
				$_FILES['logo']['type'] != 'image/png' &&
				$_FILES['logo']['type'] != 'image/jpeg'
			) {
				array_push($res['errors'], "Invalid image type (only support .png & .jpg)");
			} else if ($_FILES['logo']['size'] > 2097152) {
				array_push($res['errors'], "Error, maximum file size upload is 2MB");
			} else {
				
				$name = sanitize_title($_FILES['logo']['name']);
				
				if (
					$current_logo &&
					is_file($hub_dir.$current_logo)
				) {
					unlink($hub_dir.$current_logo);
				}
				
				if (
					move_uploaded_file(
						$_FILES['logo']['tmp_name'], 
						$hub_dir.$name
					)
				) {
					update_option('layouthub_logo', $name);
					$res['logo'] = $name;
				} else {
					array_push($res['errors'], "Error, could not upload your logo");
				}
				
			}
		}
		
		$layouthub->fn->process_save_theme_settings($_POST);
		
		echo json_encode($res);
		exit;
		
	}
	
	public function ajax_connector () {
		
		header("content-type: application/json");
		
		$connect_session = $this->lh->fn->get_connect_session();
		
		if (
			$connect_session === null ||
			!isset($_POST['connect_session']) ||
			$_POST['connect_session'] != $connect_session
		) {
			
			echo json_encode(array(
				"connect_success" => false,
				"reconnect" => true,
				"url" => admin_url('admin.php?page=layouthub&connect_session='.$connect_session),
				"message" => "Your session is expired, please reload the page to continue."
			));
			
			exit;
			
		}
		
		if (
			!wp_verify_nonce($_POST['nonce'], 'ajax_connector_nonce')
		) {
			
			$nonce = $this->lh->fn->generate_id(15);
			
			if ( get_option( 'lh_safe_login_redirect' ) !== false ) {
			    update_option('lh_safe_login_redirect', $nonce);
			} else {
			    add_option( 'lh_safe_login_redirect', $nonce, null, 'no' );
			}
			
			echo json_encode(array(
				"connect_success" => false,
				"reconnect" => true,
				"url" => admin_url('admin.php?page=layouthub&nonce='.$nonce),
				"message" => "Invalid nonce, please reload the page to continue."
			));
			exit;
		}
		
		if (
			!isset($_POST['hub_action'])
		) {
			echo json_encode(array(
				"connect_success" => false,
				"message" => "Invalid action"
			));
			exit;
		}
		
		global $layouthub;
		
		$action = $_POST['hub_action'];
		
		if (is_callable(array($layouthub->fn, 'hook_'.$action))) {
			call_user_func(array($layouthub->fn, 'hook_'.$action));
		}
		
		exit;
		
	}
	
    public function admin_page() {
		
		include_once LH_PATH.DS.'views'.DS.'admin_page.php';
        
    }
	
}