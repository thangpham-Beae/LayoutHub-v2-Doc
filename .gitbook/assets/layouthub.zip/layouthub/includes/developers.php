<?php
	
if(!defined('LH_PATH')) {
	header('HTTP/1.0 403 Forbidden');
	exit;
}

class hub_developers extends LayoutHub_Functions {
	
	public $path = '';
	
	public function __construct($hub) {
		
		$this->hub = $hub;

		$this->path = $this->hub->cfg->developer['path'];
		$this->url = $this->hub->cfg->developer['url'];
		
		if (!is_dir($this->path)) {
			mkdir($this->path, 0755);
		}
		
		if (is_dir($this->path) && !is_file($this->path.DS.'.htaccess')) {
			file_put_contents(
				$this->path.DS.'.htaccess', 
				'<IfModule mod_headers.c>'."\n".
				'  <FilesMatch "\.(ttf|ttc|otf|eot|woff|woff2|font.css|css|js|html)$">'."\n".
				'    Header set Access-Control-Allow-Origin "*"'."\n".
				'  </FilesMatch>'."\n".
				'</IfModule>'
			);
		}
		
	}
	
	public function ajax() {
		
		$task = isset($_POST['task']) ? $_POST['task'] : '';
		$slug = isset($_POST['slug']) ? urldecode($_POST['slug']) : '';
		
		switch ($task) {
			
			case 'get_library' : 
				$this->library();
				exit;
			break;
			
			case 'create_readable' : 
				$this->create_readable();
				exit;
			break;
			
			case 'create_preview' : 
				$this->create_preview();
				exit;
			break;
			
			case 'save_section_css' : 
				$this->save_section_css();
				exit;
			break;
			
			case 'download_samples' : 
				$this->download_samples();
				exit;
			break;
			
			case 'get_page' :
				
				$page = $this->get_page($slug);
				
				header('content-type: application/json');
				
				if ($page !== null) {
					echo json_encode($page);
				} else {
					echo json_encode(array('Error' => 'Page does not exist'));
				}
				
				exit;
				
			break;
			
			case 'get_section' :
			
				$section = $this->get_section($slug);
				
				header('content-type: application/json');
				
				if ($section !== null) {
					echo json_encode($section);
				} else {
					echo json_encode(array('Error' => 'Section does not exist'));
				}
				
				exit;
				
			break;
						
			case 'get_theme' :
				
				$pages = isset($_POST['pages']) ? json_decode($_POST['pages']) : true;
				$theme = $this->get_theme($slug, $pages);
				
				header('content-type: application/json');
				
				if ($theme !== null) {
					echo json_encode($theme);
				} else {
					echo json_encode(array('Error' => 'Theme does not exist'));
				}
				
				exit;
				
			break;
			
			case 'dev_build_page' :
				$this->build_page($_POST['data']);
				exit;
			break;
			
			case 'dev_download' :
				$this->download_layout($_POST['slug']);
				exit;
			break;
			
			case 'dev_sync_page' :
				$this->sync_page($_POST['slug']);
				exit;
			break;
			
		}
		
	}
	
	public function scan_developer_dir($slug, $res) {
		
		if (is_dir($this->path.DS.$slug)) {
			    
		    $dir = @opendir($this->path.DS.$slug);
		    
		    while (false !== ($file = @readdir($dir))) {
		        if (
		        	$file != '.' && 
		        	$file != '..' &&
		        	is_dir($this->path.DS.$slug.DS.$file)
		        ) {
			        if (
			        	is_file($this->path.DS.$slug.DS.$file.DS.'section.lh') ||
			        	is_file($this->path.DS.$slug.DS.$file.DS.'page.json')
			        ) {
				        
				        $node = is_file($this->path.DS.$slug.DS.$file.DS.'section.lh') ?
				        		$this->get_section(DS.$slug.DS.$file) : 
				        		$this->get_page(DS.$slug.DS.$file, false);
				        	
				        $type = (isset($node->section_id) ? 'sections' : 'pages');
				        
				        if (isset($node->category)) {
					        $cates = explode(',', $node->category);
					        foreach ($cates as $cate) {
						        $cate = trim($cate);
						        $cate = strtolower($cate);
						        if (!isset($res[$type][$cate])) {
							        $res[$type][$cate] = array();
						        }
						        array_push($res[$type][$cate], $slug.DS.$file);
					        }
				        } else {
					        array_push($res[$type]['Uncategoried'], $slug.DS.$file);
				        }
				        
				        unset($node);
				        
				        if (is_file($this->path.DS.$slug.DS.$file.DS.'page.json'))
				       		$res = $this->scan_developer_dir($slug.DS.$file, $res);
				       		
			        } else {
				        $res = $this->scan_developer_dir($slug.DS.$file, $res);
			        }
			    }
			}
		}
		
		return $res;
		
	}
	
	public function library() {
		
		$result = array(
			'items' => array(), 
			'folders' => array(),
			'folder' => isset($_POST['folder']) ? urldecode($_POST['folder']) : '',
			'total' => 0,
			'per' => 21,
			'index' => isset($_POST['index']) ? (Int)$_POST['index'] : 1,
			'ds' => DS,
			'channel' => isset($_POST['channel']) ? urldecode($_POST['channel']) : 'folder',
			'filter' => array(
				'type' => isset($_POST['type']) ? urldecode($_POST['type']) : 'section',
			)
		);
		
		/*
		*	Scan all layouts for json caching for the first time
		*/
		
		if (
			$result['channel'] == 'categories:rescan' ||
			!is_file($this->path.DS.'pages_map.json') ||
			!is_file($this->path.DS.'sections_map.json')
		) {
			
			$map = $this->scan_developer_dir('', array(
				"pages" => array(
					"Uncategoried" => array()
				),
				"sections" => array(
					"Uncategoried" => array()
				)
			));
			
			file_put_contents($this->path.DS.'pages_map.json', json_encode($map['pages']));
			file_put_contents($this->path.DS.'sections_map.json', json_encode($map['sections']));
			
			$result['channel'] = str_replace(':rescan', '', $result['channel']);
			
		}
		
		$result['folder'] = str_replace(DS.'root', '', $result['folder']);
		
		if ($result['channel'] == 'folder') {
		
			$rf ='';
			$rp ='';
			
			foreach (explode(DS, $result['folder']) as $f) {
				
				if (empty($rf) && empty($f))
					$rf .= '[\'root\']';
				else $rf .= '[\''.str_replace('\\', '\\\\', $f).'\']';
				
				$rp .= $f.DS;
				eval('$result[\'folders\']'.$rf.'=$this->get_folders(\''.str_replace('\\', '\\\\', $rp).'\');');
		
			}
			
			$result = $this->get_items($result);
		
		} else {
			
			$type = $result['filter']['type'];
			
			$result['folders'] = file_get_contents($this->path.DS.$type.'s_map.json');
			$result['folders'] = json_decode($result['folders'], true);
			$result['folder'] = isset($result['folders'][$result['folder']]) ? $result['folder'] : 'Uncategoried';
			$result['ds'] = '';
			
			$items = $result['folders'][$result['folder']];
			
			foreach($result['folders'] as $i => $v) {
				$result['folders'][$i] = count($result['folders'][$i]);
			}
				
			$start = ($result['index']-1)*$result['per'];
			$res = array();
			
			foreach ($items as $name => $path) {
				
				$result['total']++;
		    	
		    	if (
		    		$result['total'] > $start && 
		    		$result['total'] <= $start+$result['per']
		    	) {
			    	$item = $this->get_item($path, $type);
			    	if ($item !== null)
			    		array_push($res, $item);
		    	}
			}
			
			$result['items'] = $res;
			
		}
		
		header('content-type: application/json');
		echo json_encode($result);
		
	}

	public function get_folders($p) {
	
		$f = $this->path.DS.$p;
		$res = array();
		
		if (is_dir($f)) {
			    
		    $dir = @opendir($f);
		    
		    while (false !== ($file = @readdir($dir))) {
		        if (
		        	$file != '.' && 
		        	$file != '..' &&
		        	is_dir($f.$file) &&
		        	//!is_file($f.$file.DS.'page.json') &&
		        	!is_file($f.$file.DS.'section.lh')
		        ) {
			       $res[$file] = array();
			    }
			}
		}
		
		return $res;
		
	}

	public function get_items($result) {

		$p = $result['folder'];
			
		$f = $this->path.$p.DS;
		$type = $result['filter']['type'];
		$res = array();
		
		$start = ($result['index']-1)*$result['per'];
		
		if (is_dir($f)) {
			    
		    $dir = @opendir($f);
		    
		    switch ($type) {
			    case 'theme': $index = 'theme.json';break;
			    case 'page': $index = 'page.json';break;
			    default : $index = 'section.lh';break;
		    }
		    
		    while (false !== ($file = @readdir($dir))) {
		        if (
		        	$file != '.' && 
		        	$file != '..' &&
		        	is_dir($f.$file) &&
		        	is_file($f.$file.DS.$index)
		        ) {
			        
			    	$result['total']++;
			    	
			    	if (
			    		$result['total'] > $start && 
			    		$result['total'] <= $start+$result['per']
			    	) {
				    	$item = $this->get_item($p.DS.$file, $type);
				    	if ($item !== null)
				    		array_push($res, $item);
			    	}
			    }
			}
		}
		
		$result['items'] = $res;
		
		return $result;
		
	}
	
	public function get_item($slug, $type) {
		
		$res = array();
		$fpath = $this->path.DS.$slug.DS;
		
		switch ($type) {
		    case 'theme': $index = 'theme.json';break;
		    case 'page': $index = 'page.json';break;
		    default : $index = 'section.lh';break;
	    }
		
		if (
    		$index == 'page.json' || 
    		$index == 'theme.json'
    	) {
    		$item = @json_decode($this->get_file($fpath.$index));
    		if (!is_object($item)) {
	    		$item = json_decode(
	    			'{"name": "<font color=\'red\'>Decode error page /'.$slug.DS.$index.'/'.
	    			$index.'</font>", "author": "JSON syntax error"}'
	    		);
	    	} else if ($index == 'page.json') {
		    	
		    	if (
		    		isset($this->hub->cfg->teamwork) &&
		    		$this->hub->cfg->teamwork === true &&
		    		strpos($slug, DS.'TEAMWORK'.DS) === 0
		    	) {
			    	
			    	$sync = preg_replace('/[\/|\\\\]+TEAMWORK[\/|\\\\]+[\w\d\-]*[\/|\\\\]+/i', '', $slug);
			    	$task = $this->hub->db->rawQuery(
						sprintf(
							"SELECT `id`, `status` FROM `%s` WHERE `sync`='%s'", 
							$this->hub->db->prefix.'teamwork_tasks', 
							$sync
						)
					);
					
					if (count($task) > 0)	{
						$item->task = $task[0];
					} else {
			    		$item->task = array('id' => 0, "sync" => $task);
			    	}
			    	
		    	}
		    	
	    	} else if ($index == 'theme.json') {
		    	if (
			    	isset($item->pages) &&
			    	is_array($item->pages)
		    	) {
			    	for ($i = count($item->pages) - 1; $i >=0 ; $i--) {
				    	$ff = $item->pages[$i];
				    	if (
					    	is_dir($fpath.'pages'.DS.$ff) &&
				        	is_file($fpath.'pages'.DS.$ff.DS.'page.json')
				    	) {
				    		$item->pages[$i] = $this->get_page($this->path.DS.$slug.DS.'pages'.DS.$ff);
				    	} else {
					    	unset($item->pages[$i]);
				    	}
			    	}
		    	}
	    	}
    	} else if (
    		$index == 'section.lh'
    	) {
	    	$item = $this->section_schema($fpath.$index);
	    	$item = @json_decode($item[0]);
	    	
	    	if (!is_object($item)) {
	    		$item = json_decode(
	    			'{"name": "<font color=\'red\'>Schema decode error '.$slug.'/'.
	    			$index.'</font>", "author": "JSON syntax error"}'
	    		);
	    	} else {
		    	
		    	if (is_dir($fpath.'__LH') && is_file($fpath.'__LH'.DS.'preview.html'))
		    		$item->preview = 'available';
		    	
		    	if (
		    		isset($this->hub->cfg->teamwork) &&
		    		$this->hub->cfg->teamwork === true &&
		    		strpos($slug, DS.'TEAMWORK'.DS) === 0 &&
		    		is_file($this->path.DS.$slug.DS.'..'.DS.'page.json')
		    	) {
			    	$sync = explode(DS, $slug);
			    	array_pop($sync);
			    	$sync = implode(DS, $sync);
			    	$item->task = array('id' => 0, "sync" => $sync);
			    	$sync = preg_replace('/[\/|\\\\]+TEAMWORK[\/|\\\\]+[\w\d\-]*[\/|\\\\]+/i', '', $sync);
			    	$sync = $this->hub->db->rawQuery(
						sprintf(
							"SELECT `id`, `status` FROM `%s` WHERE `sync`='%s'", 
							$this->hub->db->prefix.'teamwork_tasks', 
							$sync
						)
					);
					
					if (count($sync) > 0)	{
						$item->task = $sync[0];
					} else {
			    		$item->task = array('id' => 0, "sync" => $sync);
			    	}
			    	
		    	}
		    	
	    	}
	    }
    	
    	if (
    		is_object($item)
    	) {
	    	if (
    			$type == 'page' &&
    			!isset($item->sections)
    		) {
		    	$item = json_decode(
		    		'{"name": "<font color=\'red\'>Error config file /'.$slug.DS.$index.'/'.
		    		$index.'</font>", "author": "Missing sections config", "error": true}'
		    	);
	    	} else if (
	    		$type != 'theme' &&
	    		!isset($item->task)
	    	) {
		    	$item->task = array("id" => 0);
	    	}
    	}
    	
    	if (
    		(
    			isset($item->type) &&
				$type == $item->type
			) ||
			(
				!isset($item->type) &&
				(
					$type == 'section' || 
					$type == 'page' ||
					$type == 'theme'
				)
			)
    	) {
    	
	    	$item->id = $this->hub->fn->slugify($slug);
	    	
	    	if (!isset($item->type)) {
	    		$item->type = $type;
	    	}
	    	
	    	$item->slug = $slug;
	    	$item->thumbnail = $this->get_thumbnail($item->slug);
	    	$item->url = $this->url.str_replace(DS, '/', $slug);
	    	$item->updated = time();
	    	
	    	if ($item->type == 'page' && is_file($fpath.'__LH'.DS.'preview.html'))
	    		$item->preview = 'available';
	    	
	    	return $item;
    	
    	}
    	
    	return null;
    	
	}
	
	public function get_section($slug) {
		
		$devpath = $this->path;
		$url = $this->url.str_replace(array(DS, ' '), array('/', '%20'), $slug).'/';
		
		if (
			is_dir($devpath.$slug) &&
			file_exists($devpath.$slug.DS.'section.lh')
		) {
			
			$path = $devpath.$slug.DS;
			$section_schema = $this->section_schema($path.'section.lh', $url);
			$section = @json_decode($section_schema[0]);
			
			if (!is_object($section)) {
	    		$section = json_decode('{"name": "Schema decode error file /'.$slug.'/section.lh", "author": "Unknow"}');
	    	}
			
			$section->section_id = explode(DS, $slug);
			$section->section_id = $this->hub->fn->slugify(end($section->section_id));
			
			$section->id = isset($_POST['random_id']) ? $_POST['random_id'] : $this->hub->fn->generate_id();
			$section->thumbnail = $this->get_thumbnail($slug);
	    	$section->slug = $slug;
	    	$section->css = (Object)array();
	    	
	    	$css_vendors = '';
	    	$js_vendors = '';
	    	$php_vendors = '';
	    	
	    	if (isset($section->vendors)) {
		    	
		    	foreach ($section->vendors as $key => $vendor) {
			    	
			    	$ty = explode('.', $vendor);
			    	
			    	if (is_numeric($key))
			    		$key = $this->hub->fn->generate_id();
			    	
			    	if (end($ty) == 'js') {
				    	$js_vendors .= '/***start js_vendor:'.$key.'***/'.@file_get_contents(
				    		(strpos($vendor, 'http') === false ? $url : '').$vendor
				    	).'/***end js_vendor:'.$key.'***/';
			    	} else if (end($ty) == 'css') {
				    	if (
				    		strpos($vendor, 'http') !== false &&
				    		strpos($vendor, $url) === false
				    	) {
					    	
					    	$css_vendors .= '@import url("'.(strpos($vendor, 'http') === false ? $url : '').$vendor.(
						    	strpos($vendor, '?') === false ? '?' : '&'
					    	).'vendor_id='.$key.'");';
					    	
				    	} else {
					    	
					    	$clp = str_replace(array('%URL%', DS, '/'), array('/', '/', '/'), $url.$vendor);
					    	$clp = explode('/', $clp);
					    	$clp[count($clp)-1] = '';
					    	
					    	$vendor = str_replace(array('%URL%', $url, '/'), array('', '', DS), $vendor);
					    	
					    	$css_vendors .= '/***start css_vendor:'.$key.'***/'.
					    	$this->get_file($path.$vendor, $url, implode('/', $clp)).
					    	'/***end css_vendor:'.$key.'***/';
				    	}
			    	} else if (end($ty) == 'php') {
				    	
				    	if (is_file($path.$vendor))
					    	rename($path.$vendor, $path.$vendor.'.bak');
					    
					    if (is_file($path.$vendor.'.bak')) {	
					    	$php_vendors .= '/***start php_vendor:'.$key.'***/'.
					    		@file_get_contents($path.$vendor.'.bak')
								.'/***end php_vendor:'.$key.'***/';
				    	}
				    	
			    	}
		    	}
		    	
	    	}
	    	
			$css_vendors = urldecode($css_vendors);	  
			  	
	    	$section->data = array(
		    		
	    		"url" => $url, 
				
				"settings" => $this->get_file($path.'settings.js', $url),
				
				"section" => isset($section_schema[1]) ? $section_schema[1] : '',
				
				"liquid" => $this->get_file($path.'liquid.json', $url),
				
				"php" => $this->get_file($path.'php.json', $url),
				
				"includes" => $this->get_includes($path, $url),
				
				"ajax" => $this->get_file($path.'ajax.php', $url),
				
				"js" => $js_vendors."\n/*---start js vendors---*/\n".$this->get_file($path.'script.js', $url),
				
				"css" => $this->get_file($path.'style.css', $url, $url),
				
				"css_vendors" => $css_vendors,
				
				"php_vendors" => $php_vendors
				
	    	);
			
			if (
				isset($section->type) &&
				(
					$section->type == 'header' ||
					$section->type == 'footer'
				)
			) {
				
				$hash = $this->check_hash($slug, $section);
				
				$section->hash = $hash[0];
				$section->lastHash = $hash[1];
				
			}
				
	    	return $section;
			
		} else return null;
		
	}
	
	public function get_includes($path, $url = '') {
		
		$ret = array();
		
		if (!is_dir($path.'includes') )
			return $ret;
			
		$dir = @opendir($path.'includes');
		    
	    while (false !== ($file = @readdir($dir))) {
	        if (
	        	$file != '.' && 
	        	$file != '..' &&
	        	is_file($path.'includes'.DS.$file) &&
	        	strrchr($file, '.') == '.lh'
	        ) {
		       $ret[ substr($file, 0, strlen($file)-3) ] = $this->get_file($path.'includes'.DS.$file, $url);
		    }
		}
		
		return $ret;
		
	}
	
	public function get_page($slug, $include_section = true) {
		
		$devpath = $this->path;
		
		if (
			is_dir($devpath.$slug) &&
			file_exists($devpath.$slug.DS.'page.json')
		) {
			
			$path = $devpath.$slug.DS;
			$page = @json_decode($this->get_file($path.'page.json'));
			
			if (!is_object($page)) {
	    		$page = json_decode('{"name": "Decode error file /'.$slug.'/page.json", "author": "Unknow"}');
	    	}
			
			$page->id = explode(DS, $slug);
			$page->id = $this->hub->fn->slugify(end($page->id));  	
	    	$page->thumbnail = $this->get_thumbnail($slug);
	    	$page->slug = $slug;
	    	$page->url = $this->url.str_replace(DS, '/', $slug);
	    	
	    	/*
		    *	If this is install theme action
		    */
		   
	    	if ($include_section === 'install') {
		    	
		    	if (
			    	is_file($path.'__LH'.DS.'editable.hub') &&
			    	is_file($path.'__LH'.DS.'readable.hub')
		    	) {
					$page->editable = $this->get_file($path.'__LH'.DS.'editable.hub');
					$page->readable = $this->get_file($path.'__LH'.DS.'readable.hub');
					return $page;
				} else return null;
				
			}
			
	    	if (
	    		is_array($page->sections) && 
	    		$include_section !== false
	    	) {
			    	
		    	unset($_POST['random_id']);
		    	
		    	for ($i = count($page->sections) -1; $i>=0; $i--) {
			    	if (
				    	is_dir($path.$page->sections[$i]) &&
				    	is_file($path.$page->sections[$i].DS.'section.lh')
			    	) {
				    	$page->sections[$i] = $this->get_section($slug.DS.$page->sections[$i]);
			    	} else {
				    	unset($page->sections[$i]);
			    	}
		    	}
		    	
	    	}
	    	
    		$hash = $this->check_hash($slug, $page);
			
			$page->hash = $hash[0];
			$page->lastHash = $hash[1];
			
			return $page;

	    } else {
		    
		    return null;
			
	    }
	    	
	}
	
	public function check_hash($slug = '', $data = '') {
		
		$path = $this->path.$slug.DS;
		
		$hash = (String)$this->get_hash($slug);
		
		if (!is_dir($path.'__LH')) {
			mkdir($path.'__LH', 0755);
			$lastHash = '';
		} else {
			$lastHash = $this->get_file($path.'__LH'.DS.'hash.txt');
		}
		
		if ($hash != $lastHash)
			file_put_contents($path.'__LH'.DS.'editable.hub', json_encode($data));
		
		return array($hash, $lastHash);
					
	}
	
	public function get_theme($slug, $pages = true) {
		
		$devpath = $this->path;
	
		if (
			is_dir($devpath.$slug) &&
			file_exists($devpath.$slug.DS.'theme.json')
		) {
			
			$path = $devpath.$slug.DS;
			$theme = @json_decode($this->get_file($path.'theme.json'));
			
			if (!is_object($theme)) {
	    		$theme = json_decode('{"name": "Decode error file /'.$slug.'/theme.json", "author": "Unknow"}');
	    	}
			
			$theme->id = explode(DS, $slug);
			$theme->id = $this->hub->fn->slugify(end($theme->id));	
	    	$theme->thumbnail = $this->get_thumbnail($slug);
	    	$theme->slug = $slug;
	    	
	    	if (is_array($pages)) {
	    	
		    	if (
		    		is_dir($path.'header') && 
		    		is_file($path.'header'.DS.'__LH'.DS.'editable.hub') &&
		    		is_file($path.'header'.DS.'__LH'.DS.'readable.hub')
		    	) {
			    	$theme->header = $this->section_schema($path.DS.'header'.DS.'section.lh');
			    	$theme->header = json_decode($theme->header[0]);
			    	$theme->header->editable = $this->get_file($path.'header'.DS.'__LH'.DS.'editable.hub');
			    	$theme->header->readable = $this->get_file($path.'header'.DS.'__LH'.DS.'readable.hub');
			    }
			    
			    if (
		    		is_dir($path.'footer') && 
		    		is_file($path.'footer'.DS.'__LH'.DS.'editable.hub') &&
		    		is_file($path.'footer'.DS.'__LH'.DS.'readable.hub')
		    	) {
			    	$theme->footer = $this->section_schema($path.DS.'footer'.DS.'section.lh');
			    	$theme->footer = json_decode($theme->footer[0]);
			    	$theme->footer->editable = $this->get_file($path.'footer'.DS.'__LH'.DS.'editable.hub');
			    	$theme->footer->readable = $this->get_file($path.'footer'.DS.'__LH'.DS.'readable.hub');
			    }
		    
		    }
		    	
		    if (
		    	isset($theme->pages) &&
		    	is_array($theme->pages) &&
				is_dir($path.'pages')
			) {
				
				$theme_pages = array();
				
				for ($i = count($theme->pages)-1; $i >=0; $i--) {
					$page = $theme->pages[$i];
					if(
						is_dir($path.'pages'.DS.$page) &&
			        	is_file($path.'pages'.DS.$page.DS.'page.json') &&
			        	(
				        	$pages === true ||
				        	(
				        		is_array($pages) &&
				        		in_array($page, $pages)	
				        	)
			        	) 
		        	){
			        	$theme->pages[$i] = $this->get_page(
			       			$slug.DS.'pages'.DS.$page, is_array($pages) ? 'install' : false 
				   			/*no include sections*/
			       		);
		        	} else {
			        	unset($theme->pages[$i]);
		        	}
				}
				
	    	}
	    	
			return $theme;

	    } else {
		    
		    return null;
			
	    }
	    	
	}
	
	public function get_thumbnail($slug) {
		
		
		$path = $this->path.$slug.DS;
		
	    if (file_exists($path.'thumbnail.jpg'))
	    	return $this->url.str_replace(DS, '/', $slug).'/thumbnail.jpg';
	    else if (file_exists($path.'thumbnail.jpeg'))
	    	return $this->url.str_replace(DS, '/', $slug).'/thumbnail.jpeg';
	    else if (file_exists($path.'thumbnail.png'))
	    	return $this->url.str_replace(DS, '/', $slug).'/thumbnail.png';
		else if (file_exists($path.'thumbnail.svg'))
	    	return $this->url.str_replace(DS, '/', $slug).'/thumbnail.svg';
	    else if (file_exists($path.'thumbnail.gif'))
	    	return $this->url.str_replace(DS, '/', $slug).'/thumbnail.gif';
	    else return $this->hub->cfg->assets.'images/icon.svg';
	    
	}
	
	public function get_hash($slug, $hash = 0) {
		
		if (!is_dir($this->path.$slug))
			return $hash;
		
		$dir = @opendir($this->path.$slug.DS);
		
		while (false !== ($file = readdir($dir))) {
		    if (
		    	$file != '.' &&  $file != '..'
		    ) {
			    if (is_file($this->path.$slug.DS.$file)) {
				    $ext = explode('.', $file);
				    $ext = end($ext);
				    $ext = strtolower($ext);
				    if (in_array($ext, array('js', 'css', 'json', 'lh'))) {
						$hash += filemtime($this->path.$slug.DS.$file);
					}
				} else if (is_dir($this->path.$slug.DS.$file)) {
					$hash += $this->get_hash($slug.DS.$file, $hash);
				}
		    }
		}
		
		return $hash;
		
	}
	
	public function create_readable() {
		
		$hash = $_POST['hash'];
		$slug = $_POST['slug'];
		
		if (!is_file($this->path.$slug.DS.'index.html'))
			file_put_contents($this->path.$slug.DS.'index.html', '&copy; LayoutHub.com');
			
		if (!is_dir($this->path.$slug.DS.'__LH'))
			mkdir($this->path.$slug.DS.'__LH', 0755);
			
		$path = $this->path.$slug.DS.'__LH'.DS;

		$data = $_POST['data'];
		$data = urldecode(base64_decode($data));
		$dedata = json_decode($data, true);	
		$url = urldecode(base64_decode($dedata['url']));
			
		echo (
			file_put_contents($path.'hash.txt', $hash) &&
			file_put_contents($path.'readable.hub', $data)
		);
		
	}
	
	public function create_preview() {
		
		$slug = urldecode($_POST['slug']);
		$url = $_POST['url'];
		
		if (!is_dir($this->path.$slug.DS.'__LH'))
			mkdir($this->path.$slug.DS.'__LH', 0755);
			
		$path = $this->path.$slug.DS.'__LH'.DS;
		
		if (isset($_FILES['data'])) {
			
			$data = trim(file_get_contents($_FILES['data']['tmp_name']));
			$list_images = file_get_contents($_FILES['list_images']['tmp_name']);
			$screenshot = file_get_contents($_FILES['screenshot']['tmp_name']);
			$section_screenshots = file_get_contents($_FILES['section_screenshots']['tmp_name']);
			
			/*
			*	Page screenshot
			*/
			
			$screenshot = explode('base64,', $screenshot);
			$screenshot = base64_decode($screenshot[1]);
			
			file_put_contents($this->path.$slug.DS.'thumbnail.jpg', $screenshot);
			
			/*
			* Section screenshots
			*/
			$section_screenshots = json_decode($section_screenshots, true);
			
			foreach ($section_screenshots as $ss) {
				
				$ss['data'] = explode('base64,', $ss['data']);
				$ss['data'] = base64_decode($ss['data'][1]);
				
				if (is_dir($this->path.$slug.DS.$ss['slug']))
					file_put_contents($this->path.$slug.DS.$ss['slug'].DS.'thumbnail.jpg', $ss['data']);
				else if (is_dir($this->path.$slug.DS.urldecode($ss['slug'])))
					file_put_contents($this->path.$slug.DS.urldecode($ss['slug']).DS.'thumbnail.jpg', $ss['data']);
			}
			
			
			if (is_dir($path.'static')) {
				$this->hub->fn->remove_dir($path.'static');
			}
			
			mkdir($path.'static', 0755);
			
			file_put_contents($path.'static'.DS.'index.html', '&copy; LayoutHub.com');
			
			$data = str_replace($url, '%URL%', $data);
			$list_images = json_decode($list_images, true);
			
			foreach ($list_images as $id => $img) {
				
				if (!empty($img['url_upload'])){
					
					$d = explode('base64,', $img['url_upload']);
					
					if ($img['local'] === true) {
						$p = str_replace($url, $this->path.$slug, $img['url_original']);
						$p = str_replace('/', DS, $p);
						$u = str_replace($url, '%URL%', $img['url_original']).'?ref='.time();
					} else {
						
						$t = '.jpg';
						
						if (strpos($d[0], 'image/png') !== false)
							$t = '.png';
						else if (strpos($d[0], 'image/webp') !== false)
							$t = '.webp';
						else if (strpos($d[0], 'image/svg+xml') !== false)
							$t = '.svg';
							
						$p = $path.'static'.DS.$id.$t;
						$u = '%URL%__LH/static/'.$id.$t;
					}
					
					$d = base64_decode($d[1]);
					file_put_contents($p, $d);
					
				} else {
					$u = str_replace($url, '%URL%', $img['url_original']);
				}
				/*
				* Reupdate all image by id to new url
				*/
				$data = str_replace('#unique-id-'.$id, $u, $data);
				
			}
			
			//$data = '<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>'.$data;
			
			echo file_put_contents($path.'preview.html', $data);
			exit;
			
		}
		
		echo 0;
		exit; 
		
	}
	
	private function __draft_download_images_from_string () {
	
	
		/*
		* Storage dataurl base64 images
		*/
		
		$data = preg_replace_callback(
			'/data\:image\/(webp|jpeg|png|gif|svg\+xml)\;base64\,[^\'\"\#\)]*/s', 
			function($m) use($url, $path){
				
				$val = explode('base64,', $m[0]);
				$val = base64_decode($val[1]);
				$key = $this->hub->fn->generate_id().'.';
				
				switch ($m[1]) {
					case 'webp' : $key .= 'webp'; break;
					case 'jpeg' : $key .= 'jpg'; break; 
					case 'png' : $key .= 'png'; break;
					case 'svg+xml' : $key .= 'svg'; break;
				}
				
				if (@file_put_contents($path.'static'.DS.$key, $val)) {
					return '%URL%__LH/static/'.$key;
				} else return $m[0];
			},
			$data
		);
		
		$data = preg_replace_callback(
			'/data\:image\/(webp|jpeg|png|gif|svg\+xml)\;base64\,[^\'\"\#\)]*/s', 
			function($m) use($url, $path){
				
				$val = explode('base64,', $m[0]);
				$val = base64_decode($val[1]);
				$key = $this->hub->fn->generate_id().'.';
				
				switch ($m[1]) {
					case 'webp' : $key .= 'webp'; break;
					case 'jpeg' : $key .= 'jpg'; break; 
					case 'png' : $key .= 'png'; break;
					case 'svg+xml' : $key .= 'svg'; break;
				}
				
				if (@file_put_contents($path.'static'.DS.$key, $val)) {
					return '%URL%__LH/static/'.$key;
				} else return $m[0];
			},
			$data
		);
		
		/*
		* Storage http images
		*/
		
		$data = preg_replace_callback(
			'/http([^\'\"\>\<]*)\.(jpg|png|gif|svg|woff2|woff|ttf|js|css|json)/s', 
			function($m) use($url, $path){
				
				$n = explode('/', $m[0]);
				$n = end($n);
				
				if (strpos($m[0], $url) === false) {
					if (
						(is_dir($path.'static') || mkdir($path.'static', 0755))
						&&
						@file_put_contents($path.'static'.DS.md5($m[0]).'-'.$n, @file_get_contents($m[0]))
					) return '%URL%/__LH/static/'.md5($m[0]).'-'.$n;
				} else {
					return str_replace($url, '%URL%', $m[0]);
				}
				
				return $m[0];
				
			}, 
			$data
		);
		
		
	}
	
	public function save_section_css() {
		
		$rules = urldecode(base64_decode($_POST['rules']));
		$slug = urldecode($_POST['slug']);
		
		if (!is_dir($this->path.$slug)) {
			echo 'Error, the section path is not exist: '.$slug;
			exit;
		}
		
		if (file_put_contents($this->path.$slug.DS.'style.css', $rules))
			echo 1;
		else 
			echo 'Error, could not save file '.$slug.DS.'style.css';
		
		exit;
		
	}
	
	public function download_samples() {
		
		$error = '';
		
		if (
			!isset($this->hub->cfg->developer) ||
			!is_dir($this->path)
		) {
			$error = "Error: Could not process your request";
		} else {
			
			$f = file_put_contents("samples.zip", fopen("https://library.layouthub.com/HUB/samples/DOWNLOAD.zip", 'r'), LOCK_EX);
			
			
			if (FALSE === $f) {
			    $error = "Could not download file on your server";
			} else {
				$zip = new ZipArchive;
				$res = $zip->open('samples.zip');
				if ($res === TRUE) {
					$zip->extractTo($this->path);
					$zip->close();
					if (is_dir($this->path.DS.'__MACOSX')) {
						$this->hub->fn->remove_dir($this->path.DS.'__MACOSX');
					}
					rename($this->path.DS.'DOWNLOAD', $this->path.DS.'SAMPLES');
				} else {
					$error = 'Could not extract file zip on your server';
				}
				@unlink('samples.zip');
			}
		}
		
		if (!empty($error)) {
			header('content-type: application/json');
			echo json_encode(array('error' => $error));
			exit;
		} else {
			$_POST['type'] = 'section';
			$_POST['channel'] = 'categories:rescan';
			$this->library();
		}
		
	}
	
	public function section_schema($path, $url = '') {
		
		$schema = $this->get_file($path, $url);
		
		if (strpos($schema, '@schema') === false || strpos($schema, '@endschema') === false)
			return array();
		
		$s1 = strpos($schema, '@schema')+7;
		$s2 = strpos($schema, '@endschema', $s1);
		$str = substr($schema, $s1, $s2-$s1);
		
		return array($str, str_replace(array('@schema', '@endschema', $str), '', $schema));
		
	}
	
	public function zipFolder($zip, $path, $p = '') {
		
		if (is_dir($path)) {
			    
		    $dir = @opendir($path);
		    
		    while (false !== ($file = @readdir($dir))) {
		        if (
		        	$file != '.' && 
		        	$file != '..' &&
		        	$file != '.DS_Store'
		        ) {
			        if (is_file($path.DS.$file)) {
				        $zip->addFile($path.DS.$file, ($p !== '' ? $p.'/' : '').$file);
			        } else if (is_dir($path.DS.$file)) {
				        $this->zipFolder($zip, $path.DS.$file, $p.'/'.$file);
			        } 
			    }
			}
		}
		
	}
	
	private function syncConnect($slug, $fields) {
		
		$slug = str_replace('{{DS}}', DS , $slug);
		
		$token = $this->hub->cfg->developer['sync'];
		$s = strlen($token)-18;
		$key = substr($token, $s);
		$url = trim(base64_decode(strrev(substr($this->hub->cfg->developer['sync'], 0, $s)))).urlencode($slug);
		
		$resource = curl_init();
		
		curl_setopt($resource, CURLOPT_URL, $url);
		curl_setopt($resource, CURLOPT_HTTPHEADER, array('Content-Type: multipart/form-data'));
		curl_setopt($resource, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.12) Gecko/20101026 Firefox/3.6.12');
		curl_setopt($resource, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($resource, CURLOPT_POST, 1);
		curl_setopt($resource, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($resource, CURLOPT_COOKIE, 'syncToken=' . $key);
		$result = curl_exec($resource);
		
		curl_close($resource);
		
		$result = json_decode($result);
		
		return $result;
		
	}
	
	private function build_page($data) {
		
		header('content-type: application/json');
		
		$f = $this->hub->fn->slugify($data['name']);
		$p = explode(DS, $data['path']);
		$_p = '';
		/*
		* Create path to save
		*/
		foreach ($p as $r) {
			if (!empty($r)) {
				$_p .= $r.DS;
				if (!is_dir($this->path.DS.$_p)) {
					mkdir($this->path.DS.$_p, 0755);
				}
			}
		}
		/*
		*	If page folder exists
		*/
		if (is_dir($this->path.DS.$_p.$f)) {
			echo json_encode(array(
				"success" => false,
				"message" => "Error: Page directory already exists" 
			));
			exit;
		}
		/*
		*	Create page folder
		*/
		mkdir($this->path.DS.$_p.$f, 0755);
		$sections = array();
		foreach ($data['sections'] as $section) {
			
			if (
				is_dir($this->path.$section) &&
				is_file($this->path.$section.'section.lh')
			) {
				$sname = explode(DS, $section);
				$sname = !empty($sname[count($sname)-1]) ? 
						  $sname[count($sname)-1] : 
						  $sname[count($sname)-2];
				
				while (is_dir($this->path.DS.$_p.$f.DS.$sname)) {
					$sname .= rand(1, 9);
				}
						  
				$this->hub->fn->recurse_copy(
					$this->path.$section, 
					$this->path.DS.$_p.$f.DS.$sname
				);
				
				array_push($sections, $sname);
				
			}
			
		}
		
		$pagejson = '{
	"name"		: "'.str_replace('"', '', $data['name']).'",
	"author"	: "LayoutHub",
	"website"	: "https://www.LayoutHub.com",
	"version"	: "1.0",
	"category"	: "'.str_replace('"', '', $data['category']).'",
	"platform"  : "'.str_replace('"', '', $data['platform']).'",
	"sections"	: ["'.implode('","', $sections).'"], 
	"theme" : {
        "font_family"	: "'.str_replace('"', '', $data['theme']['font_family']).'", 
        "color"			: "'.str_replace('"', '', $data['theme']['color']).'",
        "title_font_family": "'.str_replace('"', '', $data['theme']['title_font_family']).'",
        "font_size"     : "'.str_replace('"', '', $data['theme']['font_size']).'"
    }
}';

		if (file_put_contents($this->path.DS.$_p.$f.DS.'page.json', $pagejson)) {
			echo json_encode(array(
				"success" => true,
				"url" => $this->url.'/'.str_replace(DS, '/', $_p).$f,
				"slug" => DS.$_p.$f
			));
		}
		
		exit;
		
	}
	
	private function download_layout($slug) {
		
		header('content-type: application/json');

		if (
			!isset($this->hub->cfg->developer) || 
			!is_dir($this->path.$slug)
		) {
			echo json_encode(array(
				"success" => false,
				"message" => "Error: Could not process your request" 
			));
			exit;
		}
		
		$download_file = $this->path.DS.'download.zip';
		
		file_put_contents($download_file, '');
		$zip = new ZipArchive;
		
		if ($zip->open($download_file) === TRUE) {
		    $this->zipFolder($zip, $this->path.$slug, basename($slug));
		    $zip->close();
		    echo json_encode(array(
				"success" => true,
				"link" => $this->hub->cfg->developer['url'].'/download.zip'
			));
			exit;
		} else {
		    echo json_encode(array(
				"success" => false,
				"message" => "Error: Could not zip page (code 217)" 
			));
			exit;
		}
		
		
		
	}
	
	private function sync_page($slug) {
		
		header('content-type: application/json');

		if (
			!isset($this->hub->cfg->developer) || 
			!isset($this->hub->cfg->developer['sync'])
		) {
			echo json_encode(array(
				"success" => false,
				"message" => "Error: Developer sync mode disabled (code 29)" 
			));
			exit;
		}
		
		if (
			strpos($slug, " ") !== false
		) {
			echo json_encode(array(
				"success" => false,
				"message" => "Error: The path of the layout must not contain spaces and special characters" 
			));
			exit;
		}
		
		/*
		* Get form
		*/
		if (!isset($_POST['task_id'])) {
			
			$result = $this->syncConnect($slug, array("request" => "get_tasks"));
			echo json_encode($result);
			exit;
		}
		
		/*
		*	Sync with task_id
		*/
		
		$sync_file = $this->path.DS.'sync.zip';
		
		file_put_contents($sync_file, '');
		$zip = new ZipArchive;
		
		if ($zip->open($sync_file) === TRUE) {
		    $this->zipFolder($zip, $this->path.$slug, basename($slug));
		    $zip->close();
		} else {
		    echo json_encode(array(
				"success" => false,
				"message" => "Error: Could not zip page (code 27)" 
			));
			exit;
		}
		
		$fields = array(
			"task_id" => $_POST['task_id'], 
			"comment" => $_POST['comment'], 
			"file" => new CurlFile($sync_file, 'application/zip', 'sync.zip')
		);
		
		$result = $this->syncConnect($slug, $fields);
		
		unlink($sync_file);
		echo json_encode($result);
		
	}

}