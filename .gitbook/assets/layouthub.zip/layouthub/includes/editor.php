<?php
/**
 * LayoutHub Backend Editor
 *
 * @package LayoutHub
 * @since   1.0
 */

defined( 'ABSPATH' ) || exit;

define('PATH', ABSPATH.DS.'..'.DS.'layouthub'.DS);

require_once(PATH.'core'.DS.'includes'.DS.'main.php');
require_once(dirname(__FILE__).DS.'config.php');

$cfg = new hub_config();
	
global $hub;

$hub = new LayoutHub($cfg);

$cfg->register_hooks($hub);

$hub->init(); 

require_once(PATH.'core'.DS.'index.php');

