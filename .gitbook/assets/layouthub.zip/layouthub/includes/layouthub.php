<?php
/**
 * LayoutHub Setup
 *
 * @package LayoutHub
 * @since   1.0
 */

defined( 'ABSPATH' ) || exit;

class LayoutHub_Class {
	
	public $version = '';
	public $fn;
	public $backend;
	public $frontend;
	public $plugin_url;
	public $assets_url;
	
	public $app_endpoint = '';
	
	public function __construct() {
		
		$this->version = get_file_data(LH_FILE, array('Version'))[0];
		$this->app_endpoint = (is_ssl() ? 'https' : 'http').'://dev.layouthub.com/wp.php?page=page&debug=true&migration=yes';
		
		require_once LH_PATH.DS.'includes'.DS.'config.php';
		include_once LH_PATH.DS.'includes'.DS.'functions.php';
		
		$this->fn = new LayoutHub_Functions();
		$this->cfg = new hub_config();
		
		if (isset($this->cfg->developer) && is_array($this->cfg->developer)) {
			$this->dev = new hub_developers($this);
		}
		
		$this->plugin_url = plugins_url('/', LH_FILE);
		$this->assets_url = plugins_url('/assets/', LH_FILE);
		
		$upload_dir = wp_upload_dir();
		$this->upload_path = str_replace('/', DS, $upload_dir['basedir']).DS.'layouthub'.DS;
		$this->upload_url = $upload_dir['baseurl'].'/layouthub/';
		
		$this->create_page_template();
		
		if (is_admin()) {
			include_once LH_PATH.DS.'includes'.DS.'backend.php';
			$this->backend = new LayoutHub_Backend($this);
		} else {
			add_action('init', array($this, 'app_init'), 999);
		}
		
		add_filter( 'page_row_actions', array($this, 'page_row_actions'), 10, 2 );
		
		register_activation_hook(LH_FILE, array($this, 'plugin_activate'));
		
		
	}
	
	public function app_init() {
		
		if (
			isset($_GET['layouthub_api']) &&
			$_GET['layouthub_api'] == 'platform-connector'
		) {
			
			include_once LH_PATH.DS.'includes'.DS.'connector.php';
			exit;
			 
		}
		
	}
	
	public function create_page_template() {
		
		$template_path = get_template_directory().DS.'templates'.DS;
		
		if (!is_dir($template_path) && !mkdir($template_path, 0755))
			return false;
		
		if (
			!is_file($template_path.'layouthub.php') &&
			!file_put_contents(
				$template_path.'layouthub.php', 
				file_get_contents(LH_PATH.DS.'install'.DS.'page-template.php')
			)
		) return false;
		
		return true;
		
	}
	
	public function page_row_actions($actions, $post) {
		
		if ( $post->post_type != 'page' ) {
	        return $actions;
	    }
	
	    $actions['LayoutHub'] = '<a href="'.admin_url('post.php?post='.$post->ID.'&action=edit&layouthub_action=enable_editor').'">Edit with LayoutHub</a>';
	    
	    return $actions;
	    
	}
	
	public function plugin_activate() {
	    	add_option('layouthub_do_activation_redirect', true);
	}

}