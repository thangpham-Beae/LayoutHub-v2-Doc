<?php
/**
 * LayoutHub Functions
 *
 * @package LayoutHub
 * @since   1.0
 */

defined( 'ABSPATH' ) || exit;

class LayoutHub_Functions {
	
	public function __construct() {
	
	}
	
	public function hook_publish_settings ($edit_sett = array()) {
		
		$page_type = isset($_POST['page']) ? $_POST['page'] : 'page';
		$args = array();
		
        switch ($page_type) {
            
            case 'page':

                $args = array(
                    "params" => array(
                        array(
                            "name" => "page_title",
                            "label" => "Page Title",
                            "type" => "text",
                            "required" => true,
                            "value" => isset($edit_sett['page_title']) ? $edit_sett['page_title'] : ''
                        ),
                        array(
                            "name" => "page_slug",
                            "label" => "Page slug <em>".site_url('')."/<b>{slug}</b></em>",
                            "type" => "text",
                            "value" => isset($edit_sett['page_slug']) ? $edit_sett['page_slug'] : ''
                        ),
                        array(
                            "name" => "page_desc",
                            "label" => "Meta description",
                            "type" => "textarea",
                            "value"=> isset($edit_sett['page_desc']) ? $edit_sett['page_desc'] : '',
                            "max" => 320
                        ),
                        array(
                            "name" => "page_public",
                            "label" => "Public Page?",
                            "type" => "toggle",
                            "required" => false,
                            "description" => "The page only can see when you are publishing.",
                            "value" => isset($edit_sett['page_public']) ? $edit_sett['page_public'] : 'no'
                        ),
                        array(
                            "name" => "is_default",
                            "label" => "Make as Home page?",
                            "type" => "toggle",
                            "required" => false,
                            "value" => isset($edit_sett['is_default']) ? $edit_sett['is_default'] : 'no',
                            "description" => "Make default this page to replace your existing home page.",
                            "relation" => array(
                                "parent" => "page_public",
                                "show_when" => "yes"
                            )
                        )
                    ),
                    "text" => array(
                        "page_public" => array(
                            "yes" => array(
                                "primary" => "Publish page <i class=\"icon-arrow-right\"></i>",
                                "title" => "Publish your standard page",
                                "apply" => "Publish now"
                            ),
                            "no" => array(
                                "primary" => "Save page <i class=\"icon-arrow-right\"></i>",
                                "title" => "Save your draft page",
                                "apply" => "Save now"
                            )
                        )
                    )
                );
                
            break;
            
            default:
            
                $args = array(
                    "params" => array(
                        array(
                            "name" => "page_title",
                            "label" => "Page Title",
                            "required" => true,
                            "type" => "text",
                            "value" =>  ucfirst($page)." Title"
                        ),
                        array(
                            "name" => "is_default",
                            "label" => "Is Default?",
                            "type" => "toggle",
                            "value" => isset($edit_sett['is_default']) ? $edit_sett['is_default'] : 'no',
                            "description" => "Make this as a default template for your $page page"
                        )
                    ),
                    "text" => array(
                        "is_default" => array(
                            "yes" => array(
                                "primary" => "Publish page <i class=\"icon-arrow-right\"></i>",
                                "title" => "Publish layout for your $page page",
                                "apply" => "Publish now"
                            ),
                            "no" => array(
                                "primary" => "Save template <i class=\"icon-arrow-right\"></i>",
                                "title" => "Save template for $page page",
                                "apply" => "Save now"
                            )
                        )
                    )
                );
                
            break;
         
        }
        
        return $args;
		
	}
	
	public function hook_publish ($args = array()) {
		
		global $layouthub;
		
		header("content-type: application/json");
		
		if (!isset($_FILES['data'])) {
			echo json_encode(array("status" => "error", "message" => "Missing data when publishing"));
			exit;
		}
		
		$data = @json_decode(file_get_contents($_FILES['data']['tmp_name']), true);
		
		if (!$data) {
			echo json_encode(array("status" => "error", "message" => "Could not execute data"));
			exit;
		}
		
		$data['global']['combined_css'] = base64_encode(urlencode($data['css']));
		$this->process_save_theme_settings($data['global']);
		
		$this->process_save_ext($data, 'header');
		$this->process_save_ext($data, 'footer');
		
		$page_id = $this->process_save_page($data);
		
		echo json_encode(
			array(
				"status" => "success", 
				"message" => "Your page has been published successful! <p><a href=\"".get_permalink($page_id)."\" target=_blank class=\"button\">View your page</a></p>",
				"url" => isset($data['vars']) && isset($data['vars']['page-id']) ? 
							$data['ref'] : $data['ref'].'&page-id='.$page_id,
				"view_url" => get_permalink($page_id)
			)
		);
		
		exit;
		
	}
	
	public function hook_ajax () {
		if (isset($_GET['redirect'])) {
			$redi = json_decode(stripslashes(urldecode($_GET['redirect'])), true);
			if (isset($redi['page-id'])) {
				header("location: ".get_permalink($redi['page-id']));
			} else {
				wp_error('Error while redirect: missing page-id');
			}
		} else {
			global $layouthub;
			$layouthub->dev->ajax();
		}
	}

    public function hook_picker() {

        if (!isset($_POST['type']))
            return;

        header("content-type: application/json");

        $type = $_POST['type'];
		
		if ($type == 'link') { 
        		
        		echo json_encode([
        			'taxos' => [
	        			'page',
			            'images',
			            'categories',
			            'posts',
			            'woo_categories',
			            'woo_products'
		            ],
        			'taxo' => 'page'
        		]);
                exit;
                    
        }
		
        $allow_types = [
            'page',
            'images',
            'fonts',
            'categories',
            'posts',
            'post_type',
            'object_taxonomies',
            'form_integration',
            'woo_categories',
            'woo_products'
        ];

        if (!in_array($type, $allow_types)) {
            echo json_encode(array(
                "success" => false,
                "message" => "Invalid file type"
            ));
            exit;
        }

        $per = 30;
        $p = isset($_POST['p']) ? (int)$_POST['p'] : 1;
        $s = isset($_POST['s']) ? $_POST['s'] : '';

        $items = array();

        $total_count = 0;

        switch ($type){
            case 'images':
            case 'fonts':
            case 'posts':
            case 'page':
            case 'woo_products':
                if ($type == 'images')
                    $mine = 'image';
                else if ($type == 'fonts')
                    $mine = array('application/x-font-ttf', 'application/woff', 'application/woff2');

                if ($p === 1 && $type != 'posts' && $type != 'woo_products') {
                    array_push($items, array(
                        "thumbnail" => '',
                        "name" => '<i class="icon-upload"></i><text>Upload</text>',
                        "value" => "",
                        "fn" => "upload"
                    ));
                }

                $query_args = array(
                    'post_type'      => 'post',
                    'post_mime_type' => $mine,
                    'post_status'    => 'publish',
                    'posts_per_page' => $per,
                    'paged' => $p,
                    'order' => "DESC",
                    'orderby' => "date"
                );

                if ($type == 'images' || $type == 'fonts') {
                    $query_args['post_type'] = 'attachment';
                    $query_args['post_mime_type'] = $mine;
                    $query_args['post_status'] = 'inherit';
                } elseif ($type == 'woo_products') {
                    $query_args['post_type'] = array('product');
                } elseif ($type == 'page') {
                    $query_args['post_type'] = array('page');
                }

                if (!empty($s)) {
                    $query_args['s'] = $s;
                }

                $query = new WP_Query( $query_args );

                foreach ( $query->posts as $item ) {
                    if($type == 'posts' || $type == 'page' || $type == 'woo_products'){
                        $item_image = get_the_post_thumbnail_url($item->ID, [40, 40]);
                    }else{
                        $item_image = wp_get_attachment_thumb_url( $item->ID );
                    }

                    if(!$item_image){
                        $item_image = plugins_url('/assets/images/blog.svg', LH_FILE);
                    }

                    array_push($items, array(
                        "thumbnail" => $item_image,
                        "name" => $item->post_title,
                        "value" =>  ($type == 'posts' || $type == 'woo_products') ? $item->ID : wp_get_attachment_url( $item->ID ),
                        "url" => get_permalink($item->ID),
                        "fn" => "item"
                    ));
                }

                $total_count = $query->found_posts;
            
            break;
            
            case 'categories':
                $offset = ($p - 1) * $per;
                $cate_args = [
                    'hide_empty' => true,
                    'number' => $per,
                    'offset' => $offset
                ];

                $cate_args_all = [
                    'hide_empty' => true,
                ];

                if (!empty($s)) {
                    $cate_args['name__like'] = $s;
                    $cate_args_all['name__like'] = $s;
                }

                $categories = get_categories($cate_args);

                if(!empty($categories)){
                    foreach ( $categories as $item ) {
                        array_push($items, array(
                            "thumbnail" => plugins_url('/assets/images/blog.svg', LH_FILE),
                            "name" => $item->name,
                            "value" =>  $item->term_id,
                            "url" => get_category_link($item->term_id),
                            "fn" => "item"
                        ));
                    }
                }

                $total_count = count(get_categories($cate_args_all));
            break;
            
            case 'post_type':
                $types = get_post_types( [], 'objects' );
                $unset_arr = [
                    'attachment',
                    'revision',
                    'nav_menu_item',
                    'custom_css',
                    'customize_changeset',
                    'oembed_cache',
                    'user_request',
                    'wp_block',
                    'mc4wp-form'
                ];

                if(!empty($types)) {
                    foreach ($types as $k => $v) {
                        if (!in_array($k, $unset_arr)) {
                            array_push($items, array(
                                "thumbnail" => plugins_url('/assets/images/blog.svg', LH_FILE),
                                "name" => $v->label,
                                "value" => $v->name,
                                "url" => '#'.$v->name,
                                "fn" => "item"
                            ));
                        }
                    }
                }
            break;
            
            case 'object_taxonomies':
                $post_type = isset($_POST['post_type']) ? $_POST['post_type'] : 'post';
                $taxonomies = get_object_taxonomies($post_type, 'object');
                if(!empty($taxonomies)){
                    foreach ($taxonomies as $k => $v){
                        array_push($items, array(
                            "thumbnail" => plugins_url('/assets/images/blog.svg', LH_FILE),
                            "name" => $v->label,
                            "value" => $v->name,
                            "url" => '#'.$v->name,
                            "fn" => "item"
                        ));
                    }
                }
            break;
            
            case 'form_integration':
                $plugin_type = isset($_POST['plugin_type']) ? $_POST['plugin_type'] : '';
                if(!empty($plugin_type)){
                    switch ($plugin_type){
                        case 'cf7':
                            if(class_exists('WPCF7_ContactForm')){
                                $res = WPCF7_ContactForm::find([
                                    'posts_per_page' => -1
                                ]);

                                if(!empty($res)){
                                    foreach ($res as $k => $v){
                                        array_push($items, array(
                                            "thumbnail" => plugins_url('/assets/images/blog.svg', LH_FILE),
                                            "name" => $v->title,
                                            "value" => $v->id,
                                            "shortcode" => base64_encode($v->shortcode()),
                                            "url" => '#'.$v->id,
                                            "fn" => "item"
                                        ));
                                    }
                                }
                            }
                            break;
                        case 'wp_form':
                            if (defined('WPFORMS_VERSION') && function_exists('wpforms')) {
                                $forms = wpforms()->form->get();
                                if(!empty($forms)){
                                    foreach ($forms as $k => $v){
                                        array_push($items, array(
                                            "thumbnail" => plugins_url('/assets/images/blog.svg', LH_FILE),
                                            "name" => $v->post_title,
                                            "value" => $v->ID,
                                            "shortcode" => base64_encode('[wpforms id="' . $v->ID . '"]'),
                                            "url" => "#".$v->ID,
                                            "fn" => "item"
                                        ));
                                    }
                                }
                            }
                            break;
                    }
                }
            break;
            case 'woo_categories':
                $offset = ($p - 1) * $per;
                $cate_args = [
                    'taxonomy' => 'product_cat',
                    'hide_empty' => true,
                    'number' => $per,
                    'offset' => $offset
                ];

                $cate_args_all = [
                    'hide_empty' => true,
                ];

                if (!empty($s)) {
                    $cate_args['name__like'] = $s;
                    $cate_args_all['name__like'] = $s;
                }

                $categories = get_terms($cate_args);

                if(!empty($categories)){
                    foreach ( $categories as $item ) {
                        array_push($items, array(
                            "thumbnail" => plugins_url('/assets/images/blog.svg', LH_FILE),
                            "name" => $item->name,
                            "value" =>  $item->term_id,
                            "url" =>  get_term_link($item->term_id, 'product_cat'),
                            "fn" => "item"
                        ));
                    }
                }

                $total_count = count(get_categories($cate_args_all));
                break;
        }

        echo json_encode(array(
            "data" => $items,
            "metadata" => array(
                "total_count" => $total_count,
                "next_page" => ($p*$per) < $total_count ? $p+1 : 0
            )
        ));
        exit;

    }
	
    public function hook_proxy() {
	  
	    header("content-type: application/json");
		
		if (isset($_POST['url']) && !empty($_POST['url'])) {
			$res = $this->remote(
				$_POST['url'],
				isset($_POST['data']) ? $_POST['data'] : array()
			);
			echo $res;
		}
		
		exit;
		
    }
	
	public function hook_load_icons() {
	
		$url = str_replace(' ', '%20', urldecode($_POST['url']));
		$content = $this->remote($url);
		
		if (isset($_POST['base']) && !empty($_POST['base'])) {
			$content = str_replace(
				array(
					'%URL%/', '%url%/', '%URL%', '%url%'
				), 
				str_replace(' ', '%20', urldecode($_POST['base']))
				, 
				$content
			);
		}
		
		$path = explode('/', $url);
		array_pop($path);
		$path = implode('/', $path).'/';
	    $content = preg_replace('/(url\(\"(?!.*\/\/))/i', '$1'.$path, $content);
	    $content = preg_replace('/(url\(\'(?!.*\/\/))/i', '$1'.$path, $content);
	    
		header('content-type: application/json');
		echo json_encode(array(
            "data" => $content
        ));
		
		exit;
	
	}
	
	public function hook_workspace ($cp = '') {
		
		global $layouthub;
		
		if (function_exists('set_current_screen'))
			set_current_screen('layouthub_editor');
		
		$wptheme = wp_get_theme();
		$templates = $wptheme->get_page_templates();
		$theme_path = get_template_directory().DS;
		$content = '';
		
		if (!$layouthub->create_page_template()) {
			return '<p class="notice error">Error! Could not create template file on your current theme.</p>';
		}
		
		ob_start();
		/*
		* Let the template file know this is request from editor
		*/
		$GLOBALS['layouthub_is_editor'] = true;
		include_once($theme_path.'templates'.DS.'layouthub.php');
		$content = ob_get_contents();
		ob_end_clean();
		
		$content = preg_replace('/<link [^>]*id=([\'\"])layouthub-global-css\\1[^>]*>/ms', '', $content);
		
		$content = preg_replace_callback(
			'/<script[\s\S]+?\<\/script\>/s', 
			function($m) {
				if (
					preg_match('/<script[^>]*data-layouthub="allow"/', $m[0]) ||
					(
						isset($vars['insert']) &&
						($vars['insert'] == 'top' || $vars['insert'] == 'bottom')
					)
				) return $m[0];
				return '';
			},
			$content
		);
			
		return $content;
		
	}
			
	public function hook_upload () {
			
		if (
			!isset($_POST['type']) || 
			($_POST['type'] != 'image' && $_POST['type'] != 'font')
		) return;
			
		header("content-type: application/json");
		
		require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
		
		$attachment_id = media_handle_upload('upload', 0);
		
		if ( is_wp_error( $attachment_id ) ) {
			echo json_encode(array(
				"success" => false,
				"message" => $attachment_id->get_error_message()
			));
		} else {
			echo json_encode(array(
				"success" => true,
				"thumbnail" => wp_get_attachment_thumb_url($attachment_id),
				"value" => wp_get_attachment_url($attachment_id)
			));
		}
		
		exit;
		
	}
		
	public function hook_server_scripts () {
		
		$scripts = isset($_POST['scripts']) ? $_POST['scripts'] : '';
		$page = isset($_POST['page']) ? $_POST['page'] : '';

		if (is_string($scripts)) {
			$this->server_scripts = (Object)json_decode(urldecode(base64_decode($scripts)));
		} else $this->server_scripts = (Object)$scripts;
		
		/*
		*	Start building the pre-render liquid
		*/
		$server_scripts_raw = '';
		
		foreach ($this->server_scripts as $name => $lq) {
			$server_scripts_raw .= '<!---'.$name.'--->'.$lq.'<!---commit--->';
		}
		/*
		*	Combined all liquid into a request
		*/ 
			
		ob_start();
			
			if (
				isset($_POST['vendors']) && 
				!empty($_POST['vendors'])
			) {
				eval('?>'.urldecode(base64_decode($_POST['vendors'])));
				ob_clean();
			}
			
			eval('?>'.$server_scripts_raw);
			$server_scripts_rendered = ob_get_contents();
			
		ob_end_clean();
		
		/*
		*	Return the results into object before responding
		*/
		
		preg_replace_callback( 
			'/<\!---(.*?)--->(.*?)\<\!---commit--->/s', 
			array(&$this, 'server_scripts_return'), 
			$server_scripts_rendered 
		);
		
		header("content-type: application/json");
		echo json_encode($this->server_scripts);
		exit;
		
	}
	
	public function server_scripts_return($m) {
		$this->server_scripts->{$m[1]} = trim($m[2]);
	}
	
	public function hook_section_ajax() {
		
		unset($_POST['nonce']);
		unset($_POST['action']);
		unset($_POST['ajax']);
		unset($_POST['scripts']);
		
		$this->hook_server_scripts();
	
	}
	
	public function __insame_hook_server_scripts ($raw) {
		
		if (!$raw || empty($raw))
			return '';
			
		ob_start();
			
			if (
				isset($_POST['vendors']) && 
				!empty($_POST['vendors'])
			) {
				eval('?>'.urldecode(base64_decode($_POST['vendors'])));
				ob_clean();
			}
			
			eval('?>'.$raw);
			$re = ob_get_contents();
			
		ob_end_clean();
		
		return $re;
		
	}
	
	public function hook_theme_settings ($st = array()) {
		/*
		* Return theme settings for editor via init action
		*/
		$st = array(
			"global_fullpage" => get_option("layouthub_global_fullpage", "no"),
			"color" => get_option("layouthub_color", "#14C39B"),
			"font_size" => get_option("layouthub_font_size", "15"),
			"font_family" => get_option("layouthub_font_family", ""),
			"title_font_family" => get_option("layouthub_title_font_family", ""),
			"custom_css" => get_option("layouthub_custom_css", ""),
			"typo" => get_option("layouthub_typo", "")
		);
		
		return $st;
		
	}
	
	public function hook_exit_nav ($arg = array()) {
		
		return array(
			array(
				"link" => admin_url(
					isset($_POST['page_id']) ? 
					'/post.php?post='.$_POST['page_id'].'&action=edit' :
					'/post-new.php?post_type=page'
				),
				"icon" => "icon-pencil-alt",
				"title" => "WP edit page"
			),
			array(
				"link" => admin_url(),
				"icon" => "icon-home",
				"title" => "WP dashboard"
			),
			array(
				"link" => 'https://app.layouthub.com',
				"icon" => "icon-dashboard",
				"title" => "App settings"
			)
		);
		
	}
	
	public function hook_theme_header ($return) {
		
		$theme = wp_get_theme();
		
		if (
			$theme->get('Name') == 'LayoutHub' && 
			$theme->stylesheet == 'layouthub'
		) {
			$head_path = get_option('layouthub-header');
			$head_path = urldecode($head_path);
			return $this->get_editable($head_path);
		} else return false;
		
	}
	
	public function hook_theme_footer ($return) {
		
		$theme = wp_get_theme();
		
		if (
			$theme->get('Name') == 'LayoutHub' && 
			$theme->stylesheet == 'layouthub'
		) {
			$foot_path = get_option('layouthub-footer');
			$foot_path = urldecode($foot_path);
			return $this->get_editable($foot_path);
		} else return false;
		
	}
	
	public function hook_connector_init () {
		
		global $layouthub;
		
		$meta = array();
		
		if (
			isset($_POST['page_id']) &&
			!empty($_POST['page_id'])
		) {
			
			$meta = get_post_meta( $_POST['page_id'], 'layouthub', true);
			
			if ($meta) {
				$meta = $this->get_editable(urldecode($meta));
			} else {
				$meta = array();
			}
			
			$meta['url'] = get_permalink($_POST['page_id']);
			
			if (isset($_POST['page_id'])) {
				$post = get_post($_POST['page_id']);
				if ($post) {
					$meta['settings'] = array(
						"page_publish" => ($post->post_status == 'publish') ? 'yes' : 'no',
						"page_title" => $post->post_title,
						"page_slug" => $post->post_name,
						"page_desc" => $post->post_excerpt,
						"is_home" => get_option('page_on_front') == $post->ID ? "yes" : "no"
					);
				}
			}
			
			$edit_page = $meta;
			
		} else {
			$edit_page = "";
		}
		
		if (!is_array($meta['settings']))
			$meta['settings'] = array();
				
		$dev_url = '';
		
		if (
			isset($layouthub->cfg->developer) && 
			is_array($layouthub->cfg->developer)
		) {
			$dev_url = $layouthub->cfg->developer['url'];
		}
		
		echo json_encode ( array(
			"success" => true,
			"data" => array(
				"developer" =>  array(
					"enabled" => !empty($dev_url) ? true : false,
					"url" => $dev_url
				),
				"server_script" => 'php',
				"workspace" => $this->hook_workspace(),
				"publish_settings" => $this->hook_publish_settings($meta['settings']),
				"edit_page" => $edit_page,
				"theme" => array(
					"settings" => $this->hook_theme_settings(),
					"header" => false,
					"footer" => false
				),
				"exit_nav" => $this->hook_exit_nav()
			)
		));
		
		exit;
				
	}
	
	public function process_save_layout($save_path = '', $args = array()) {
		
		global $layouthub;
		$hub_path = $layouthub->upload_path;
		
		if (
			!$save_path ||
			!is_dir($hub_path.$save_path)
		) {
			
			$yy = date('Y', time());
			$yymm = date('Y', time()).DS.date('m', time());
			
			if (
				(
					!is_dir($hub_path) &&
					!mkdir($hub_path, 0755)
				) ||
				(
					!is_dir($hub_path.DS.$yy) &&
					!mkdir($hub_path.DS.$yy, 0755)
				) ||
				(
					!is_dir($hub_path.DS.$yymm) &&
					!mkdir($hub_path.DS.$yymm, 0755)
				) ||
				(
					!is_dir($hub_path.DS.$yymm.DS.$args['id']) &&
					!mkdir($hub_path.DS.$yymm.DS.$args['id'], 0755)
				)
			) {
				echo json_encode(array(
					"status" => "error",
					"message" => "Could not create folder"
				));
				exit;
			}
			
			$save_path = $yymm.DS.$args['id'];
			
		}
		
		$begi = "<?php defined( 'ABSPATH' ) || exit; if (is_file(dirname(__FILE__).DS.'vendors.php')) { require_once(dirname(__FILE__).DS.'vendors.php'); } ?>";
		
		if (isset($args['ajax'])) {
			file_put_contents($hub_path.$save_path.DS.'ajax.php', $begi.$args['ajax']);
		}
		
		if (isset($args['php'])) {
			file_put_contents($hub_path.$save_path.DS.'vendors.php', "<?php defined( 'ABSPATH' ) || exit; ?>".$args['php']);
		}
		
		if (
			false === file_put_contents($hub_path.$save_path.DS.'index.php', $begi.$args['code']) ||
			false === file_put_contents($hub_path.$save_path.DS.'style.css',  $args['css']) ||
			false === file_put_contents($hub_path.$save_path.DS.'script.js',  $args['js']) ||
			false === file_put_contents($hub_path.$save_path.DS.'editable.json', $args['editable'])
		) {
			echo json_encode(array("status" => "error", "message" => "Could not save file editable.json"));
			exit;
		}
		
		return $save_path;
	}
	
	public function process_save_ext($data, $type) {
		
		if (!isset($data[$type]) || empty($data[$type]))
			return;
		
		global $layouthub;
		
		if ($data[$type] == 'none') {
			
			$get_cur = get_option('layouthub-'.$type);
			$get_cur = urldecode($get_cur);
			
			if ($get_cur) {
				
				if (is_dir($layouthub->upload_path.$get_cur)) {
					$layouthub->fn->remove_dir($layouthub->upload_path.$get_cur);
				}
				
				delete_option('layouthub-'.$type);
				
			}
			
			return;
			
		}
			
		$ext_path = get_option('layouthub-'.$type);
		$ext_path = urldecode($ext_path);
		
		$save_path = $this->process_save_layout($ext_path, array(
			"php" => $data['export'][$type]['php'],
			"code" => $data['export'][$type]['code'],
			"css" => $data['export'][$type]['css'],
			"js" => $data['export'][$type]['js'],
			"ajax" => $data['export'][$type]['ajax'],
			"editable" => json_encode($data[$type]),
			"id" => $type
		));
		
		if ($save_path != $ext_path) {
			update_option( 'layouthub-'.$type, urlencode($save_path));
		}
		
		update_option( 'layouthub-'.$type.'-time', time());
		
	}
	
	public function process_save_page($data) {
	
		$page_settings = is_array($data['settings']) ? $data['settings'] : array();

		//Render page content for this page
		$page_content = $this->get_page_content($data);
		
		if (
			!isset($data['vars']) ||
			!isset($data['vars']['page-id']) ||
			get_post($data['vars']['page-id']) === null
		) {
		/*
		*	Create new page
		*/
			$page_id = wp_insert_post(array(
				"ID" => 0,
				"post_title" => isset($page_settings['page_title']) ? $page_settings['page_title'] : '',
				"post_name" => isset($page_settings['page_slug']) ? $page_settings['page_slug'] : '',
				"post_content" => $page_content,
				"post_status" => isset(
					$page_settings['page_publish']
				) && $page_settings['page_publish'] == 'yes' ? "publish" : "draft",
				"post_type" => "page"
			));
		} else { 
			/*
			*	Update current page
			*/
			$page_id = $data['vars']['page-id'];
			wp_update_post(array(
				"ID" => $page_id,
				"post_title" => isset($page_settings['page_title']) ? $page_settings['page_title'] : '',
				"post_name" => isset($page_settings['page_slug']) ? $page_settings['page_slug'] : '',
				"post_content" => $page_content,
				"post_status" => isset(
					$page_settings['page_publish']
				) && $page_settings['page_publish'] == 'yes' ? "publish" : "draft",
				"post_type" => "page"
			));
		}
		
		$page_path = get_post_meta( $page_id, 'layouthub', true);
		$page_path = urldecode($page_path);
		
		if (isset($data['header'])) {
			unset($data['header']);
			unset($data['export']['header']);
		}
		
		if (isset($data['footer'])) {
			unset($data['footer']);
			unset($data['export']['footer']);
		}
			
		$save_path = $this->process_save_layout($page_path, array(
			"php" => $data['export']['php'],
			"code" => $data['export']['code'],
			"css" => $data['export']['css'],
			"js" => $data['export']['js'],
			"ajax" => $data['export']['ajax'],
			"editable" => json_encode($data),
			"id" => $page_id
		));
		
		if ($save_path != $page_path) {
			update_post_meta( $page_id, 'layouthub', urlencode($save_path));
			update_post_meta( $page_id, 'layouthub-time', time());
		}
		
		update_post_meta($page_id, '_wp_page_template', 'templates/layouthub.php');
		
		return $page_id;
		
	}
	
	public function clear_menu ($id = 0) {
		
		global $wpdb;
		
		$term = get_term( $id );
		
		if (false !== $term) {			
			$posts = $wpdb->get_results(
				"SELECT `object_id` FROM `{$wpdb->prefix}term_relationships` WHERE `term_taxonomy_id`=".$term->term_taxonomy_id
			);
			foreach ($posts as $post) {
				wp_delete_post($post->object_id, true);
			}
		}
		
	}
	
	public function get_file ($f, $url = '', $surl = '') {
		
		if (!is_file($f) || filesize($f) === 0)
			return '';
			
		$file = fopen($f, "r") or die("Unable to open file: $f");
		$content = fread($file, filesize($f));
		fclose($file);
		
		if (strpos($content, '<<EOF') !== false) {
			$content = preg_replace_callback( '/<<EOF\n*(.*?)\n*EOF/s', function($m) {
				return json_encode(trim($m[1]));
			}, $content );
		}
		
		if (!empty($url)) {
			$content = str_replace(array( '%URL%/', '{{URL}}/', '%URL%', '{{URL}}', '%url%/', '{{url}}/', '%url%', '{{url}}'), $url, $content);
		}
		
		if (!empty($surl)) {
			$content = preg_replace_callback('/url\([\'"]?([^\)\'"]*)[\'"]?\)/s', function($m) use($surl) {
				if (
					strpos($m[1], 'http') === 0 ||
					strpos($m[1], '//') === 0
				) return $m[0];
				$n = explode('/', $m[1]);
				if ($n[0] === '' || $n[0] == '.')
					unset($n[0]);
				return 'url(\''.$surl.implode('/', $n).'\')';				
			}, $content);
		}
		
		return $content;
		
	}
	
	public function post ($url, $data) {
		
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		$output = curl_exec($ch);
		
		curl_close ($ch);
		
		return $output;
		
	}
	
	public function remote($url = '', $data = array(), $headers = array(), $post = 0) {
	    
	    if (empty($url) || strpos($url, 'http') !== 0)
	    	return null;
	    
	    $url = str_replace(' ', '%20', $url);
	    
	    if (function_exists('curl_version')){
		    
		    $ch = curl_init();
		    
		    curl_setopt($ch, CURLOPT_URL, $url);
		    
		    if ($post === 1) {
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
				curl_setopt($ch, CURLOPT_POST, 1);
		    }
		    
		    if (is_array($data) && count($data) > 0) {
		    	$data = http_build_query($data);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		    }
		    
		    if (is_array($headers) && count($headers) > 0)
		    	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		    $res = curl_exec($ch);
		    curl_close($ch);
		    
		    return $res;
		    
	    } else if (ini_get('allow_url_fopen')) {
		    return file_get_contents($url);
	    } else {
			return 'Error: Your server does not allow outbound connections (curl, fopen & file_get_contents)';   
		}
    }
	
	public function hex2rgba ($color = '', $opacity = false) {

		$default = 'rgb(0,0,0)';
		
		if (empty($color))
          return $default; 
          
        if ($color[0] == '#')
        	$color = substr( $color, 1 );
        
        if (strlen($color) == 6) {
                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
        } elseif ( strlen( $color ) == 3 ) {
                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
        } else {
            return $default;
        }
        
        $rgb =  array_map('hexdec', $hex);
        
        if ($opacity){
        	if(abs($opacity) > 1)
        		$opacity = 1.0;
        	$output = 'rgba('.implode(",",$rgb).','.$opacity.')';
        } else {
        	$output = 'rgb('.implode(",",$rgb).')';
        }
        
        return $output;
        
	}
	
	public function recurse_copy($src, $dst) { 
		
	    $dir = opendir($src);
	     
	    if (!is_dir($dst) && !mkdir($dst, 0755))
	    	return false;
	    
	    while (false !== ($file = readdir($dir))) { 
	        if (
	        	$file != '.'
	        	&&
	        	$file != '..'
	        ) { 
	            if ( is_dir($src.DS.$file) ) { 
	                $this->recurse_copy($src.DS.$file, $dst.DS.$file); 
	            } else { 
	                copy($src.DS.$file, $dst.DS.$file); 
	            } 
	        } 
	    } 
	    
	    closedir($dir); 
	    
	    return true;
	    
	} 
	
	public function slugify($text) {
		
		// replace non letter or digits by -
		$text = preg_replace('~[^\pL\d]+~u', '-', $text);
		
		// transliterate
		$text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
		
		// remove unwanted characters
		$text = preg_replace('~[^-\w]+~', '', $text);
		
		// trim
		$text = trim($text, '-');
		
		// remove duplicate -
		$text = preg_replace('~-+~', '-', $text);
		
		// lowercase
		$text = strtolower($text);
		
		if (empty($text)) {
			return 'n-a';
		}
		
		return $text;
	
	}
	
	public function create_hub_files ($path, $data) {

		if (!isset($data['readable']) || !isset($data['editable']))
			return false;
		
		$url = str_replace(array(ABSPATH, DS), array(site_url('/'), '/'), $path);
			
		if (!is_dir($path))
				mkdir($path, 0755);
		
		$decode_data = json_decode($data['readable'], true);
		$old_url = urldecode(base64_decode($decode_data['url']));
		$args = array("path" => $path, "old_url" => $old_url, "new_url" => $url);
		
		global $resource_downloaded;
		
		$resource_downloaded = array();
		
		if (isset($decode_data['ajax'])) {
			$decode_data['ajax'] = $this->download_resources($decode_data['ajax'], $args);
			file_put_contents($path.DS.'ajax.php', "<?php defined( 'ABSPATH' ) || exit; ?>".$decode_data['ajax']);
		}
		/*
		*	Download resources
		*/
		foreach (array('code', 'js', 'css') as $n) {
			$decode_data[$n] = $this->download_resources($decode_data[$n], $args);
		}
		/*
		*	Update downloaded resource for editable.json
		*/
		if (count(array_keys($resource_downloaded)) > 0) {
			$data['editable'] = preg_replace_callback(
				'/http[s]?:([^\'"]*)\.(jpg|png|gif|svg|ttf|woff2|woff|otf|css|json|js|hub)/s', 
				function($m) {
					global $resource_downloaded;
					if (isset($resource_downloaded[stripslashes($m[0])]))
						return addslashes($resource_downloaded[stripslashes($m[0])]);
					return $m[0];
				}, 
				$data['editable']
			);
		}
		
		if (
			file_put_contents(
				$path.DS.'index.php', "<?php defined( 'ABSPATH' ) || exit; ?>".$decode_data['code']
			) &&
			file_put_contents($path.DS.'style.css', $decode_data['css']) &&
			file_put_contents($path.DS.'script.js', $decode_data['js']) &&
			file_put_contents($path.DS.'editable.json', $data['editable'])
		) return true;
		
		return false;
		
	}
	
	public function download_resources($content = '', $args = array()) {
		
		return preg_replace_callback(
			
			'/\%URL\%([^\'"]*)\.(jpg|png|gif|svg|ttf|woff2|woff|otf|css|json|js|hub)/s', 
			
			function($m) use($args){
				
				$data = $this->remote_download($args['old_url'].$m[1].'.'.$m[2]);
				
				/* Error while download: return original url */
				if (!$data)
					return $args['old_url'].$m[1].'.'.$m[2];
					
				$name = urldecode(strtolower(trim($m[1].'.'.$m[2])));
				$name = str_replace(array('/', ' '), array('_', '-', '-'), $name);
				
				if (!is_dir($args['path'].DS.'assets'))
					mkdir($args['path'].DS.'assets', 0755);
					
				if (file_put_contents($args['path'].DS.'assets'.DS.$name, $data)) {
					
					global $resource_downloaded;
					$resource_downloaded[$args['old_url'].$m[1].'.'.$m[2]] = $args['new_url'].'/assets/'.$name;
					
					return $args['new_url'].'/assets/'.$name;
					
				} else return $args['old_url'].$m[1].'.'.$m[2];
				
			}, 
			
			$content
			
		);
		
	}
	
	public function remote_download($url) {    
		
		if (function_exists('curl_version')) {   
		    
		    $ch = curl_init($url);   
		          
		    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			    'Accept: image/gif, image/x-bitmap, image/jpeg, image/pjpeg',
			    'Connection: Keep-Alive',
			    'Content-type: application/x-www-form-urlencoded;charset=UTF-8'
		    ));         
		    curl_setopt($ch, CURLOPT_HEADER, 0);         
		    curl_setopt($ch, CURLOPT_USERAGENT, 'php');    
		    curl_setopt($ch, CURLOPT_TIMEOUT, 30);         
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);         
		    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);         
		    $content = curl_exec($ch);         
		    curl_close($ch);
		             
		    return $content;
		    
		} else if (ini_get('allow_url_fopen')) {
		    
		    return file_get_contents($url);
		    
	    } else {
			return null;   
		}
	    
	}
	
	public function process_save_theme_settings ($data) {
		
		global $layouthub;
		
		$args = array();
		$is_updated = false;
		
		foreach (array(
			"developer" => 1,
			"global_fullpage" => 3,
			"color" => 20,
			"font_family" => 20,
			"title_font_family" => 20,
			"font_size" => 5,
			"custom_css" => 2000,
			"custom_js" => 2000
		) as $name => $max) {
			
			if (
				isset($data) &&
				isset($data[$name]) &&
				strlen($data[$name]) <= $max &&
				$data[$name] != get_option('layouthub_'.$name)
			) {
				update_option('layouthub_'.$name, $data[$name]);
				$args[$name] = $data[$name];
				$is_updated = true;
			}
		}
		
		$this->create_settings($data);
	
	}
	
	public function create_settings ($data) {
		
		global $layouthub;
		
		$hub_dir = $layouthub->upload_path;
		$hub_url = $layouthub->upload_url;
		
		if (
			!is_dir($hub_dir) &&
			!mkdir($hub_dir, 0755)
		) {
			return "Error, could not create folder";
		}
		
		if (isset($data['combined_css'])) {	
			if (!file_put_contents($hub_dir.'global.css', urldecode(base64_decode($data['combined_css'])))) {
				return "Error, could not create global css file";
			} else {
				update_option('layouthub-global-css', time());	
			}
		}
		
		if (isset($data['custom_js'])) {
			if (
				$data['custom_js'] !== null &&
				!file_put_contents($hub_dir.'global.js', urldecode(base64_decode($data['custom_js'])))
			) 
				return "Error, could not create global js file";
			else 
				update_option('layouthub-global-js', time());	
		}
		
		return true;
		
	}
		
	public function get_editable($meta) {
		
		global $layouthub;
		
		$lh_path = $layouthub->upload_path;
		
		if (
			$meta &&
			is_file($lh_path.$meta.DS.'editable.json')
		) {
			$editable = file_get_contents($lh_path.$meta.DS.'editable.json');
			return @json_decode($editable, true);
		}
		
		return array();
		
	}
	
	public function add_lang($data) {
		
		return preg_replace_callback(
			'/<([^\s]*)([^>]+?data\-lhi(?=[\=|\s|\>])[^>]*>)([\s\S]+?)<\/\1>/i', 
			function($m) {
				$s = str_replace("'", "\'", trim($m[3]));
				$s = preg_replace('/\s+/', ' ',$s);
				$s = '<?php echo hub_lang(\''.$s.'\'); ?>';
				return '<'.$m[1].$m[2].$s.'</'.$m[1].'>';
			},
			$data
		);
		
	}
	
	public function remove_dir ($dirPath = '') {

		if (empty($dirPath))
			return false;
	
		$dirPath = rtrim( $dirPath, '/\\' ).DS;
	
		if (defined(ABSPATH) && $dirPath == ABSPATH)
			return false;
	
	    if (! is_dir($dirPath)) {
	        return false;
	    }
	
	    $files = scandir($dirPath, 1);
	
	    foreach ($files as $file) {
		    if ($file != '.' && $file != '..') {
		        if (is_dir($dirPath.$file)) {
		        	$this->remove_dir($dirPath.$file);
		        } else {
		            unlink($dirPath.$file);
		        }
	        }
	    }
	
	    if (is_file($dirPath.'.DS_Store'))
	    	unlink($dirPath.'.DS_Store');
	
	    return rmdir($dirPath);
	
	}

	private function get_page_content($data){
	    $page_content = '';
	    if(!empty($data)) {
            if(isset($data['export']) && isset($data['export']['code']) && !empty($data['export']['code'])){
                $html = $data['export']['code'];

                // Remove div text span script tags html
                $html = preg_replace( '/<\/?div[^>]*\>/i', '', $html );
                $html = preg_replace( '/<\/?text[^>]*\>/i', '', $html );
                $html = preg_replace( '/<\/?span[^>]*\>/i', '', $html );
                $html = preg_replace( '#<script(.*?)>(.*?)</script>#is', '', $html );

                //Remove attribute in html tags
                $html = preg_replace( '/<i [^>]*><\\/i[^>]*>/', '', $html );
                $html = preg_replace('# class=".*?"| class=\'.*?\'| data-lhi=".*?"| data-lhi=\'.*?\'#', '', $html);
                $html = preg_replace('# data-section-id=".*?"| data-section-id=\'.*?\'| data-section=".*?"| data-section=\'.*?\'#', '', $html);

                // Remove empty lines.
                $html = preg_replace( '/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/', "\n", $html );
                $html = trim( $html );
                $page_content = balanceTags($html);
            }
        }
        return $page_content;
    }
	
	public function generate_id($length = 10) {
		
		return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);

	}
	
	public function esc($string = '') {
		
	   $string = preg_replace('/[^A-Za-z0-9\-\_]/', '', $string);
	
	   return $string;

	}
	
	public function ibase($s = '') {
		return base64_encode($s.(str_repeat(' ', 3-strlen($s)%3)));
	}
	
	public function hash_token( $token ) {
		
		if ( function_exists( 'hash' ) ) {
			return hash( 'sha256', $token );
		} else {
			return sha1( $token );
		}
		
	}
	
	private function get_sessions() {
		
		$uid = get_current_user_id();
        $sessions = get_user_meta( $uid, 'session_tokens', true );
 
        if ( ! is_array( $sessions ) ) {
            return array();
        }
 
        $sessions = array_map( array( $this, 'prepare_session' ), $sessions );
        
        return array_filter( $sessions, array( $this, 'is_still_valid' ) );
        
    }
    
    public function get_connect_session() {
	    
	    $uid = get_current_user_id();
	    $sessions = $this->get_sessions();
	    $current_token = wp_get_session_token();
	    $hash_token =  $this->hash_token($current_token);
	    
	    if (isset($sessions[$hash_token])) {
		    if (!isset($sessions[$hash_token]['connect-layouthub'])) {
			    $sessions[$hash_token]['connect-layouthub'] = $this->generate_id(34);
			    update_user_meta($uid, 'session_tokens', $sessions);
		    }
		    return $sessions[$hash_token]['connect-layouthub'];
	    }
	    
	    return null;
	    
    }
    
    public function get_connect_token() {
	    
	    $session = $this->get_connect_session();
		$token = time().'|'.urlencode(site_url('/')).'|'.$session.'|'.time();
		$token = strrev($this->ibase($token));
		
		return $token;
		
    }
    
    protected function prepare_session( $session ) {
        if ( is_int( $session ) ) {
            return array( 'expiration' => $session );
        }
 
        return $session;
    }
    
    protected function is_still_valid( $session ) {
	    return $session['expiration'] >= time();
	}
	
}