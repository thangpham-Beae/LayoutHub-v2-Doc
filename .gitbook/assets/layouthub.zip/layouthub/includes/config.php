<?php
	
defined( 'ABSPATH' ) || exit;

class hub_config {
	
	public $database;
	
	public $ajax;
	public $url;
	public $assets;
	public $upload_path = '';
	public $upload_url = '';
	public $io = true;
	public $darkmode = true;
	public $server_script = 'php';

	public $teamwork = false;
	
	public function __construct() {
		
		$this->database = array(
			"host" => DB_HOST,
            "user" => DB_USER,
            "pass" => DB_PASSWORD,
            "name" => DB_NAME,
			"prefix" => "hub_"
		);
		
		$this->ajax = admin_url('admin.php?page=layouthub&editor=true&hub-router=ajax');
		$this->url = site_url('/../layouthub/index.php');
		$this->assets = site_url('/../layouthub/core/assets/');
		
		$this->upload_path = ABSPATH.DS.'wp-content'.DS.'uploads'.DS.'layouthub';
		$this->upload_url = site_url('/wp-content/uploads/layouthub');
		
		if (!is_dir($this->upload_path)) {
			@mkdir($this->upload_path, 0755);
		}
		
		if (!is_file(ABSPATH.DS.'wp-content'.DS.'.htaccess')) {
			file_put_contents(
				ABSPATH.DS.'wp-content'.DS.'.htaccess', 
				'<IfModule mod_headers.c>'."\n".
				'  <FilesMatch "\.(ttf|ttc|otf|eot|woff|woff2|font.css|css|js|html)$">'."\n".
				'    Header set Access-Control-Allow-Origin "*"'."\n".
				'  </FilesMatch>'."\n".
				'</IfModule>'
			);
		}
		
		if (get_option("layouthub_developer", true) === '1') {
			include_once LH_PATH.DS.'includes'.DS.'developers.php';
			$this->developer = array(
				'path' => ABSPATH.DS.'wp-content'.DS.'uploads'.DS.'layouthub'.DS.'developer',
				'url' => site_url('/wp-content/uploads/layouthub/developer')
			);
		
		}
		
	}
	
	public function register_hooks($hub) {
		
		global $layouthub;
		
		$hub->add_filter('publish_settings', array($layouthub->fn, 'hook_publish_settings'));
		
		$hub->add_action('publish', array($layouthub->fn, 'hook_publish'));
		
		$hub->add_action('ajax', array($layouthub->fn, 'hook_ajax'));
		
		$hub->add_action('picker', array($layouthub->fn, 'hook_picker'));
		
		$hub->add_filter('workspace', array($layouthub->fn, 'hook_workspace'));
			
		$hub->add_action('upload', array($layouthub->fn, 'hook_upload'));
		
		$hub->add_filter('server-scripts', array($layouthub->fn, 'hook_server_scripts'));
		
		$hub->add_filter('theme-settings', array($layouthub->fn, 'hook_theme_settings'));
		
		$hub->add_filter('edit-page', array($layouthub->fn, 'hook_edit_page'));
		
		$hub->add_filter('theme-header', array($layouthub->fn, 'hook_theme_header'));
		
		$hub->add_filter('theme-footer',array($layouthub->fn, 'hook_theme_footer'));

	}
	
	public function is_admin() {
		return is_admin();
	}
	
}
