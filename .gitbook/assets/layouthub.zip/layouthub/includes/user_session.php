<?php

defined( 'ABSPATH' ) || exit;

class LayoutHub_User_Session extends WP_Session_Tokens {

	protected function get_sessions($uid = null) {
		
		if ($uid === null)
			$uid = get_current_user_id();
		
		$sessions = get_user_meta( $uid, 'session_tokens', true );

		if ( ! is_array( $sessions ) ) {
			return array();
		}

		$sessions = array_map( array( $this, 'prepare_session' ), $sessions );
		
		return array_filter( $sessions, array( $this, 'is_still_valid' ) );
		
	}
	
	protected function is_still_valid( $session ) {
		return $session['expiration'] >= time();
	}
	
	protected function prepare_session( $session ) {
		if ( is_int( $session ) ) {
			return array( 'expiration' => $session );
		}

		return $session;
	}
	
	public function get( $verifier, $uid = null ) {
		
		$sessions = $this->get_sessions($uid);

		if ( isset( $sessions[ $verifier ] ) ) {
			return $sessions[ $verifier ];
		}

		return null;
	}

	public function update( $verifier, $session = null, $uid = null ) {
		
		$sessions = $this->get_sessions($uid);

		if ( $session ) {
			$sessions[ $verifier ] = $session;
		} else {
			unset( $sessions[ $verifier ] );
		}

		$this->update_sessions( $sessions, $uid );
	}
	
	protected function update_sessions( $sessions, $uid = null ) {
		
		if ($uid === null)
			$uid = get_current_user_id();
			
		if ( $sessions ) {
			update_user_meta( $uid, 'session_tokens', $sessions );
		} else {
			delete_user_meta( $uid, 'session_tokens' );
		}
		
	}

}