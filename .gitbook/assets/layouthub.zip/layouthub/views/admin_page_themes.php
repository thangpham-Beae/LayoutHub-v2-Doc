<div class="wrap about-wrap full-width-layout">
	
	<h1><?php _e('Welcome to LayoutHub', 'layouthub'); ?> (Beta)</h1>
	
	<p class="about-text">
		<?php _e('The all-in-one solution for building content, with a massive library on many categories.', 'layouthub'); ?>
		<br>
		<?php _e('Includes a free live editor and blank theme that focuses on simplicity and quickness.', 'layouthub'); ?>
	</p>
	
	<div class="wp-badge lh-badge"><?php _e('Version', 'layouthub'); ?> <?php echo esc_attr($this->lh->version); ?></div>
	
	<p>
		<nav class="nav-tab-wrapper wp-clearfix" id="lh-nav-tab">
			<a href="#themes" class="nav-tab nav-tab-active">
				<?php _e('Themes Library', 'layouthub'); ?>
			</a>
			<a href="#settings" class="nav-tab">
				<?php _e('Theme Settings', 'layouthub'); ?>
			</a>
			<a href="#license" class="nav-tab">
				<?php _e('License', 'layouthub'); ?>
			</a>
			<a href="#feedback" class="nav-tab">
				<?php _e('Feedback', 'layouthub'); ?>
			</a>
		</nav>
	</p>
	
</div>

<div id="lh-main-body" class="wrap theme-install-php"></div>