<?php
	
	// Silence is gold