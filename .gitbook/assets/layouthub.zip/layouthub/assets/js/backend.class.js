export default function($, tmpl_fn) {
	
	let fn = {
		
		ss : {
			state : {}
		},
		
		state : function(n, v) {
			
			if (this.ss.state[n] === undefined) {
				this.ss.state[n] = Math.random().toString(36).slice(2);
			};
			/*
			*	Attributes
			*/
			let el = $('[data-state-id="state-'+this.ss.state[n]+'"]');		
			if (typeof v == 'object') {
				
				let attr = ['data-state-id="state-'+this.ss.state[n]+'"'];
				
				for (let i in v) {
					if (i != 'id') {
						if (v[i] !== null) {
							attr.push(i+'="'+v[i]+'"');
							el.attr(i, v[i]);
						} else el.removeAttr(i);
					}	
				};
				
				return ' '+attr.join(' ');
				
			} else {
				el.html(v);
				return `<text data-state-id="state-${this.ss.state[n]}">${v}</text>`;
			}
			
		},
		
		click: function() {
			
			let _this = this;
			
			$('#lh-main-body').on('click', function(e) {
				
				let fn = '',
					el;
					
				if (e.target.getAttribute('data-fn')) {
					fn = e.target.getAttribute('data-fn');
					el = e.target;
				} else if ($(e.target).closest('[data-fn]').length > 0) {
					fn = $(e.target).closest('[data-fn]').attr('data-fn');
					el = $(e.target).closest('[data-fn]').get(0);
				}
				
				if (typeof _this.click_fn[fn] == 'function') {
					_this.click_fn[fn].bind(el)(e, _this.click_fn);
				};
				
			});
			
			return this;
				
		},
		
		click_fn : {
			
			themes : function(e) {
				$('#lh-main-body').
					html('').
					append(
						tmpl.filter(tmpl)).append(
							tmpl.themes(fn.ss.themes
						)
					);
				e.preventDefault();
			},
			
			theme : function(e) {
				
				let id = this.getAttribute('data-id'),
					theme = fn.ss.themes.items.filter(
						(t) => {
							return t.id == id;
						}
					)[0];
					
				$('#lh-main-body').
					html('').
					append(tmpl.back_themes(theme)).
					append(tmpl.pages(theme && theme.pages ? theme.pages : []));
				
				e.preventDefault();
				
			},
			
			install_theme : function(e) {
				
				if (!this.getAttribute('disabled')) {
					
					let conf = $(tmpl.confirm()),
						li = conf.find('div[is="menu"] ul li'),
						reval = () => {
							li.each(function() {
								if (!$(this).find('input[is="inmenu"]').prop('checked')) {
									$(this).parent().append(this);
									if ($(this).find('i[is="homepage"]').hasClass('active'))
										$(this).find('i[is="homepage"]').removeClass('active');
								}
							});
							if (
								li.find('i[is="homepage"].active').length === 0 &&
								conf.find('div[is="menu"] ul li').first().find('input[is="inmenu"]').prop('checked')
							) {
								conf.find('div[is="menu"] ul li').first().find('i[is="homepage"]').addClass('active');
							}
						},
						theme = this.getAttribute('data-id');
					
					$('body').append(conf);
					
					conf.find('input[type="checkbox"]').on('change', function() {
						if (this.id == 'lh-conditions-confirm') {
							if (this.checked)
								$('#lh-install-now').removeAttr('disabled');
							else $('#lh-install-now').attr({'disabled': ''});
						} else if (!this.checked){
							reval();
						}
					});
					
					conf.on('click', function(e) {
						if (e.target.className == 'lh-confirm')
							conf.remove();
					}).find('button.secondary,i[is="close"]').on('click', () => {conf.remove();});
					
					conf.find('#lh-install-now').on('click', function(e) {
						
						let bod = $(this).closest('div[is="body"]'),
							pages = {},
							home = '';
						
						conf.find('div[is="menu"] ul li').each(function() {
							pages[this.getAttribute('data-id')] = $(this).find('input[is="inmenu"]').prop('checked');
						});
						
						if (li.find('i[is="homepage"].active').length > 0) {
							home = li.find('i[is="homepage"].active').parent().attr('data-id');
						};
						
						bod.addClass('loading-content').
							html(
								`<p>
									<span class="spinner"></span>
									<center>
										<strong>Downloading the package..</strong>
									</center>
								</p>`
							);
						
						$.post(ajaxurl, {
							action: 'layouthub_install_theme',
							nonce: layouthub_data.nonce,
							slug: theme,
							pages: pages,
							home_page: home
						}, (res) => {
							if (res.success) {
								bod.html(
									'<i class="dashicons dashicons-no-alt" is="close" onclick="$(\'.lh-confirm\').remove()"></i>'+
									'<h3>Congratulations!</h3>'+
									'<p>You have successfully installed the theme package.</p>'+
									'<p>\
										<a href="'+res.url+'" class="button button-primary button-large">View your site</a> \
									</p>'
								);
							} else {
								bod.html(
									'<h3 style="color:red;margin-bottom: 20px;">Installation failed!</h3><div class="notice error" style="text-align: left;background: #fafafa;"><p>'+res.msg+'</p></div>'
								);
							}
						});
						
					});
					
					conf.find('div[is="menu"] ul').sortable({
						handle: 'i[is="arrange"]',
						update: reval
					}).find('i[is="homepage"]').on('click', function() {
						
						if (
							!$(this).parent().find('input[is="inmenu"]').prop('checked')
						) return;
						
						if (
							!$(this).hasClass('active')
						) {
							conf.find('i[is="homepage"]').removeClass('active');
							$(this).addClass('active');
						} else {
							conf.find('i[is="homepage"]').removeClass('active');
						}
					});
					
				}
					
			},
			
			page_count : function() {
				
				let c = $('#lh-theme-pages').find('.lh-page.selected').length,
					d = $('#lh-theme-pages').find('.lh-page:not(.selected)').length;
				
				fn.state('page-count', c);
				
				if (c === 0) {
					fn.state('install-btn', {disabled: ''});
					fn.state('select-all', {checked: false});
				} else {
					fn.state('install-btn', {disabled: null});
				};
				if (d === 0)
					fn.state('select-all', {checked: true});
			},
			
			show_filters : () => {
				$('body').toggleClass('show-filters');	
			},
			
			page : function(e, f) {
				$(this).toggleClass('attachment details selected');
				f.page_count();
			},
			
			select_all : function(e, f) {
				if (this.checked) {
					$('#lh-theme-pages').find('.lh-page[data-fn="page"]').addClass('attachment details selected');
					fn.state('install-btn', {disabled: null});
				} else {
					$('#lh-theme-pages').find('.lh-page.selected[data-fn="page"]').removeClass('attachment details selected');
					fn.state('install-btn', {disabled: ''});
				};
				
				f.page_count();	
			},
			
			switch_color_picker : function(e) {
				
				let inp = $(e.target).parent().find('input');	
				
				if (inp.attr('type') == 'color')
					inp.attr('type', 'text');
				else
					inp.attr('type', 'color');
			},
			
			delete_logo : function(e, f) {
				
				e.target.setAttribute('disabled', true);
				
				$.post(
					ajaxurl, 
					{
						'action': 'layouthub_save_theme_settings', 
						'task': 'delete_logo',
						'nonce': layouthub_data.nonce
					},
					f.settings_res
				);
			},
			
			save_theme_settings : function(e, f) {
				
				e.target.setAttribute('disabled', '');
				
				let formData = new FormData(),
					wrp = $('#lh-main-body');
				
				formData.append('action', 'layouthub_save_theme_settings');
				formData.append('nonce', layouthub_data.nonce);
				
				if (wrp.find('input[name="logo"]').get(0).files.length === 1) {
					formData.append('logo', wrp.find('input[name="logo"]').get(0).files[0]); 
				};
				
				let sett = {
					developer: wrp.find('input[name="developer"]').prop('checked') ? '1' : '0',
					global_fullpage: wrp.find('input[name="global_fullpage"]').prop('checked') ? 'yes' : 'no',
					color: wrp.find('input[name="color"]').val(),
					font_family: wrp.find('input[name="font_family"]').val(),
					title_font_family: wrp.find('input[name="title_font_family"]').val(),
					font_size: wrp.find('input[name="font_size"]').val(),
					custom_css: wrp.find('textarea[name="custom_css"]').val(),
					custom_js: wrp.find('textarea[name="custom_js"]').val()
				};
				
				sett.combined_css = btoa(encodeURIComponent(fn.combined_css(sett)));
				sett.custom_css = btoa(encodeURIComponent(sett.custom_css));
				sett.custom_js = btoa(encodeURIComponent(sett.custom_js));
				
				Object.keys(sett).forEach((k) => {
					formData.append(k, sett[k]);
				});
				
				$.ajax({
				    data	:	 formData,
				    type	:	 "POST",
				    url		:	 ajaxurl,
				    contentType: false,
					processData: false,
				    xhr		:	 function() {
					    var xhr = new window.XMLHttpRequest();
					    xhr.upload.addEventListener("progress", function(evt){
						    
						    if (evt.lengthComputable) {
						        var percent = evt.loaded / evt.total;
						    }
						    
					    }, false);
					    return xhr;
					},
				    
				    success: (res) => {
					    f.settings_res(res);
					    e.target.removeAttribute('disabled');
				    },
				    
				    error: function() {}
				    
				});
				
				
			},
			
			settings_res : function(res) {
			    
			    $('td[is="logo-input"] p[is="preview"],td[is="logo-input"] [data-fn="delete_logo"]').remove();
			    
			    if (res.logo) {
				    $('td[is="logo-input"]').
				    prepend('<p is="preview"><img src="'+layouthub_data.upload_dir.baseurl+'/layouthub/'+res.logo+'" style="max-height:150px" /></p><input type="button" value="Delete logo" data-fn="delete_logo" />');
			    }
			    
			    $('#lh-main-body div.notice').remove();
			    
			    if (res.errors.length == 0) {
			   		 $('#lh-main-body').prepend('<div class="notice updated"><p>Your settings have been saved</p></div>');
			   	} else {
				   	res.errors.map(function(er) {
					   	$('#lh-main-body').prepend('<div class="notice error"><p>'+er+'</p></div>');
				   	});
			   	};
			   	
			   	$('#lh-main-body input[type="file"]').each(function() {
				   	this.type = 'text';
				   	this.value = '';
				   	this.type = 'file';
			   	});
			   	
			    $('html,body').animate({scrollTop: 0});
			    
		    }
				
		},
		
		noxss : (s) => {
			return typeof s != 'string' ? s : 
					s.replace(/(["'])?\s*javascript\s*\:[^\1]+?\1/, '#xss-removed').
					  replace(/<\s*script\s*[^\>]*>[\s\S]+<\/script\s*>/gi, ' (xss removed) ').
					  replace(/\son[\w]+\s*=/gi, ' data-xss=');
		},
		
		font : (ff) => {
			
			if (ff.trim().indexOf('http') === 0) {
				
				let fname = ff.split('/').pop().split('.')[0],
					ftype = ff.split('.').pop().split('?')[0].split('&')[0].split('#')[0];
				
				if (ftype == 'ttf')
					ftype = 'truetype';
					
				return {
					src: 'data:text/css;charset=utf-8,%40font-face%20%7Bfont-family%3A%20%27'+fname+'%27%3Bsrc%3A%20url%28%27'+ff+'%27%29%20format%28%27'+ftype+'%27%29%3B',
					name: fname
				};	
			};
			
			return {
				src: 'https://fonts.googleapis.com/css?family='+ff.replace(/\ /g, '+')+':100,200,300,400,500,600,700,800,900',
				name: ff
			};
			
		},
		
		to_rgb : (c) => {
				
			if (c.toLowerCase().indexOf('rgb') > -1) {
				let o = c.match(/rgb[a]?\s*\(([^\,]*)\,([^\,]*)\,([^\,]*)([^\)]*)\)/);
				return o[1]+', '+o[2]+', '+o[3];	
			};
			
			let h = c.charAt(0)=="#" ? c.substring(1,7) : c,
				r = parseInt(h.substring(0,2),16),
				g = parseInt(h.substring(2,4),16),
				b = parseInt(h.substring(4,6),16);
			
			return r+', '+g+', '+b;
			
		},
		
		combined_css: function(sett) {
			
			let css_data = 'body input,body textarea,body button,body select {font-family: inherit;}section[data-layouthub="section"], [data-layouthub="section"] * {padding: 0px;margin: 0px;}',
				globe = ['color: #7A7A7A'],
				head = ['color: #1A1A1B'],
				vari = [],
				google_fonts = [],
				uploaded_fonts = [],
				//sett = hub.fn.theme_cfg(),
				chek = (s) => {return s !== null && s !== undefined && s !== '';};
			
			if (
				chek(sett.font_family)
			) {
				let hff = fn.font(sett.font_family);
				if (
					sett.font_family.indexOf('http') === -1 &&
					google_fonts.indexOf(sett.font_family+':100,200,300,400,500,600,700,800,900') === -1
				) {
					google_fonts.push(sett.font_family+':100,200,300,400,500,600,700,800,900');
				} else if (
					sett.font_family.indexOf('http') > -1 &&
					uploaded_fonts.indexOf(sett.font_family) === -1
				) {
					uploaded_fonts.push(hff.src);
				};
				globe.push('font-family: "'+hff.name+'" !important');
				vari.push('--lh-font-family: "'+hff.name+'" !important');
			};
			
			if (
				chek(sett.title_font_family)
			) {
				let htff = fn.font(sett.title_font_family);
				if (
					sett.title_font_family.indexOf('http') === -1 &&
					google_fonts.indexOf(sett.title_font_family+':100,200,300,400,500,600,700,800,900') === -1
				) {
					google_fonts.push(sett.title_font_family+':100,200,300,400,500,600,700,800,900');
				} else if (
					sett.title_font_family.indexOf('http') > -1 &&
					uploaded_fonts.indexOf(sett.title_font_family) === -1
				) {
					uploaded_fonts.push(htff.src);
				};
				head.push('font-family: "'+htff.name+'" !important');
				vari.push('--lh-title-font-family: "'+htff.name+'" !important');
			};
			
			if (
				chek(sett.font_size)
			) {
				let hfs = sett.font_size+(isNaN(sett.font_size) ? '' : 'px');
				css_data += 'html {font-size: '+hfs+' !important}';
				vari.push('--lh-font-size: '+hfs+' !important');
			};
			
			if (
				chek(sett.color)
			) {
				vari.push('--lh-color: '+sett.color+' !important');
				vari.push('--lh-color-rgb: '+fn.to_rgb(sett.color)+' !important');
			};
			
			if (vari.length > 0) {
				css_data += '*{'+vari.join(';')+';}';
			};
			
			if (sett.global_fullpage != 'no') {
				css_data += 'html, body{'+globe.join(';')+';}';
				css_data += 'h1, h2, h3, h4, h5 {'+head.join(';')+';}';
			} else{
				css_data += 'body section[data-layouthub="section"] {'+globe.join(';')+';}';
				css_data += 'section[data-layouthub="section"] h1, section[data-layouthub="section"] h2, section[data-layouthub="section"] h3, section[data-layouthub="section"] h4, section[data-layouthub="section"] h5 {'+head.join(';')+';}';
			};
			
			if (
				typeof sett.typo == 'object' &&
				sett.typo.length > 0
			) {
				
				sett.typo.map(function(typo) {
					
					var _t = [], _h = [];
					
					if (
						chek(typo.font_family)
					) {
						if (
							typo.font_family.indexOf('http') === -1 &&
							google_fonts.indexOf(typo.font_family+':100,200,300,400,500,600,700,800,900') === -1
						) {
							google_fonts.push(typo.font_family+':100,200,300,400,500,600,700,800,900');
						} else if (
							typo.font_family.indexOf('http') > -1 &&
							uploaded_fonts.indexOf(typo.font_family) === -1
						) {
							uploaded_fonts.push(fn.font(typo.font_family).src);
						};
						_t.push("font-family: '"+fn.font(typo.font_family).name+"' !important");
					};
					if (chek(typo.color))
						_t.push("color: "+typo.color+" !important");
					if (chek(typo.size))
						_t.push("font-size: "+typo.size+" !important");
					if (chek(typo.weight))
						_t.push("font-weight: "+typo.weight+" !important");
					if (chek(typo.color_hover))
						_h.push("color: "+typo.color_hover+" !important");
					
					if (_t.length > 0) {
						css_data += (sett.global_fullpage == 'no' ? 'section[data-layouthub="section"] ' : '')+typo.tag+
									(chek(typo.class) && typo.class !== '' ? '.'+typo.class : '')+
									'{'+_t.join(';')+'}';
					};
					
					if (_h.length > 0) {
						css_data += (sett.global_fullpage == 'no' ? 'section[data-layouthub="section"] ' : '')+typo.tag+
									(chek(typo.class) ? '.'+typo.class : '')+
									':hover{'+_h.join(';')+'}';
					}
					
				});
			};
			
			if (
				chek(sett.custom_css)
			) {
				css_data += fn.noxss(sett.custom_css);
			};
			
			if (google_fonts.length > 0) {
				css_data = '@import url("https://fonts.googleapis.com/css?family='+google_fonts.join('|').
							replace(/\ /g, '+')+'");'+
							css_data;
			};
			
			if (uploaded_fonts.length > 0) {
				uploaded_fonts.map((uf) => {
					css_data = '@import url("'+uf+'");'+css_data;
				});
			};
			
			return css_data;
			
		},
		
		nav: () => {
			
			$('#lh-nav-tab a').on('click', function(e) {
				switch (this.getAttribute('href')) {
					case '#settings':
						$('#lh-main-body').html('').append(tmpl.settings());
					break;
					case '#terms':
						$('#lh-main-body').html('').append(tmpl.terms());
					break;
				};
				$('#lh-nav-tab a.nav-tab-active').removeClass('nav-tab-active');
				$(this).addClass('nav-tab-active');
			});
			
			if (
				window.location.href.indexOf('#') > -1 && 
				$('#lh-nav-tab a[href="#'+window.location.href.split('#')[1]+'"').length > 0
			) {
				$('#lh-nav-tab a[href="#'+window.location.href.split('#')[1]+'"').click();
			} else {
				$('#lh-nav-tab a').first().click();
			};
			
		},
		
		load_themes : () => {
			
			if (fn.ss.themes === undefined) {
				
				$('#lh-main-body').
					addClass('loading-content').
					html('<br><span class="spinner"></span>');
				
				fn.set_url('PoweredBy', 'LayoutHub.com');
					
				$.get('http://localhost/LH/LIBRARY/api/v2/wordpress/theme/all.json', (res) => {
						
						res.items.unshift({
							id: 'empty', 
							name: 'Blank theme', 
							author: 'LayoutHub', 
							pages: []
						});
						
						fn.ss.themes = res;
						$('#lh-main-body').removeClass('loading-content');
						
						fn.load_themes();
						
					}
				);
				
				fn.set_url('PoweredBy', null);
				
				return;
				
			};
			
			$('#lh-main-body').
				html('').
				append(tmpl.filter(tmpl)).
				append(tmpl.themes(fn.ss.themes));
				
			fn.set_url('PoweredBy', 'LayoutHub.com');
			$.get('http://localhost/LH/LIBRARY/api/v2/wordpress/theme_categories.json', (res) => {
				$('#hub-theme-categories div.buttons').first().after(tmpl.categories(res));
				window.theme_categories = res;
			});
			fn.set_url('PoweredBy', null);
		},
		
		set_url : (name, val) => {

			var url = window.location.href;

			url = url.split('#')[0].replace(/\,/g, '').split('?');

			if (url[1]) {

				var ur = {};

				url[1].split('&').map(function(s){
					s = s.split('=');
					ur[s[0]] = s[1];
				});

				url[1] = [];

				if (val === null)
					delete ur[name];
				else ur[name] = val;

				Object.keys(ur).map(function(s){
					url[1].push(s+'='+ur[s]);
				});

				url = url[0]+'?'+url[1].join('&');

			} else if(val !== null) {
				url = url[0]+'?'+name+'='+val;
			};

			window.history.replaceState({}, "", url);

		}
		
	}, tmpl = tmpl_fn(fn);
	
	return fn;
	
}