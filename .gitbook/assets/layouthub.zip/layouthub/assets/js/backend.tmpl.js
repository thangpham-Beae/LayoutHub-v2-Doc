export default function(fn) {
	
	return {
		
		settings : () => {
			
			let custom_css = layouthub_data['custom_css'] !== undefined && layouthub_data['custom_css'] !== '' ? layouthub_data['custom_css'] : '',
				custom_js = layouthub_data['custom_js'] !== undefined && layouthub_data['custom_js'] !== '' ? layouthub_data['custom_js'] : '';
					
			try {
				custom_css = decodeURIComponent(atob(custom_css)).
									replace(/\<textarea/g, '&lt;textarea').
									replace(/\<\/textarea\>/g, '&lt;\/textarea\>');
			} catch (ex) {
				custom_css = '';
			};
			
			try {
				custom_js = decodeURIComponent(atob(custom_js)).
									replace(/\<textarea/g, '&lt;textarea').
									replace(/\<\/textarea\>/g, '&lt;\/textarea\>');
			} catch (ex) {
				custom_js = '';
			}
			
			return `
				<table class="form-table">
					<tbody>
						<tr>
							<th><label for="user_login">Upload logo</label></th>
							<td is="logo-input">
								${layouthub_data.logo ? '<p is="preview"><img src="'+layouthub_data.upload_dir.baseurl+'/layouthub/'+layouthub_data.logo+'" style="max-height:150px" /></p><input type="button" value="Delete logo" data-fn="delete_logo" />' : ''}
								<input type="file" name="logo" accept="image/png,image/jpeg" value="" class="regular-text">
								<p class="description">Recommended file format *.PNG And height is 70px. It uses for the logo in the header and favicon.</p>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Developer mode</label></th>
							<td>
								<input type="checkbox" name="developer" class="regular-text" ${layouthub_data['developer'] == '1' ? 'checked' : '' } />
								<p class="description">
									Enable developer mode to development your layouts in your site. When open library, you will see a new tab "Developer". <br>All layout files are located in <code>/wp-content/uploads/layouthub/developer/</code>
								</p>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Primary color</label></th>
							<td>
								<input type="color" value="${layouthub_data.color}" style="padding: 0px 2px;width: 150px;height: 32px;" name="color" value="" class="regular-text">
								&nbsp; 
								<i class="dashicons dashicons-controls-repeat" style="cursor:pointer;padding-top: 7px;" data-fn="switch_color_picker"></i>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Body font</label></th>
							<td>
								<input type="text" class="regular-text" name="font_family" value="${layouthub_data['font_family']}" />
								<p class="description">The font-family of site body</p>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Heading font</label></th>
							<td>
								<input type="text" class="regular-text" name="title_font_family" value="${layouthub_data['title_font_family']}" />
								<p class="description">The font-family of H1, H2, H3, H4, H5, H6</p>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Font size (px)</label></th>
							<td>
								<input type="text" value="${layouthub_data['font_size']}" class="regular-text" name="font_size">
								<p class="description">The font-size of the page body</p>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Custom CSS</label></th>
							<td>
								<textarea name="custom_css" rows="8" placeholder="" cols="60">${custom_css}</textarea>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Custom Javascript</label></th>
							<td>
								<textarea name="custom_js" rows="8" placeholder="" cols="60">${custom_js}</textarea>
							</td>
						</tr>
						<tr>
							<th><label for="user_login">Apply full page</label></th>
							<td>
								<input type="checkbox" name="global_fullpage" class="regular-text" ${layouthub_data['global_fullpage'] == 'yes' ? 'checked' : '' } />
								<p class="description">
									Apply global style to full page (including header, footer)<br>
									Unchecking will only apply css to the content of LayoutHub.
								</p>
							</td>
						</tr>
					</tbody>
				</table>
				<p class="submit">
					<input type="submit" data-fn="save_theme_settings" name="submit" id="submit" class="button button-primary" value="Save settings">
				</p>
			`;	
		},
		
		terms : () => {
			return `<h3>Terms of service</h3>`
		}
		
	}
	
}