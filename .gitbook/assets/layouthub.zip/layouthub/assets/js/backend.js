import tmpl_class from './backend.tmpl.js';
import fn_class from './backend.class.js';

jQuery(document).ready(function($) {
	
	fn_class($, tmpl_class).click().nav();
		
});