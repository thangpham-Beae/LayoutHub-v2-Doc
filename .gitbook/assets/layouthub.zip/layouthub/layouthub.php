<?php
/**
 * Plugin Name: LayoutHub
 * Plugin URI: https://www.layouthub.com/platforms/wordpress/
 * Description: The all-in-one solution for building content, with a massive library of thousands of free layouts. Also offer an optimized theme & a free live editor
 * Version: 1.1
 * Author: LayoutHub Team
 * Author URI: https://www.layouthub.com
 * Text Domain: layouthub
 * Domain Path: /i18n/languages/
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'DS' ) ) {
	define( 'DS', DIRECTORY_SEPARATOR );
}

if ( ! defined( 'LH_FILE' ) ) {
	define( 'LH_FILE', __FILE__ );
}

if ( ! defined( 'LH_PATH' ) ) {
	define( 'LH_PATH', dirname(__FILE__) );
}

if ( ! defined( 'LH_VER' ) ) {
	$lh_version = get_file_data( __FILE__, array('Version') );
	define( 'LH_VER', is_array($lh_version) ? $lh_version[0] : 0 );
}

if ( ! class_exists( 'LayoutHub_Class' ) ) {
	include_once LH_PATH.DS.'includes'.DS.'layouthub.php';
}

$GLOBALS['layouthub'] = new LayoutHub_Class();

