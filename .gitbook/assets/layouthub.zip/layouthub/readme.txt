=== LayoutHub ===
Contributors: layouthub, king-theme, kingcomposer, lumise
Requires at least: 5.0
Tested up to: 5.2
Stable tag: 5.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

An all-in-one solution for building content, with a massive library on many categories.

== Description ==

An all-in-one solution for building content, with a massive library on many categories.	Includes a free live editor + blank theme that focuses on simplicity and quickness.

LayoutHub is developed and supported by King-Theme, the creators of KingComposer.com and Lumise.com

== Changelog ==

= 1.1 - 2019-07-30 =
* First releasing
