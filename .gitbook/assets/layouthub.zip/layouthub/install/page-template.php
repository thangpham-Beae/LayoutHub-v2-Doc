<?php 
/* 
Template Name: LayoutHub Display	
*/

defined( 'ABSPATH' ) || exit;

if (!defined('DS'))
	define('DS', DIRECTORY_SEPARATOR);

if (!defined('LH_DISPLAY'))
	define('LH_DISPLAY', '1.1');
	
$upload_dir = wp_upload_dir();
$page_id = get_queried_object_id();
$lh_meta = get_post_meta( $page_id, 'layouthub', true);

$is_global_css = get_option('layouthub-global-css');
$is_global_js = get_option('layouthub-global-js');

$is_editor = isset($GLOBALS['layouthub_is_editor']) && $GLOBALS['layouthub_is_editor'] === true;
$lh_path = str_replace('/', DS, $upload_dir['basedir']).DS.'layouthub'.DS;
$lh_layout = '';

/*
* Start theme settings
*/

if ($is_global_css && is_file($lh_path.'global.css')) {
	wp_enqueue_style(
		'layouthub-global', 
		$upload_dir['baseurl'].'/layouthub/global.css',
		array(),
		$is_global_css
	);
}

if ($is_global_js && is_file($lh_path.'global.js')) {
	wp_enqueue_script(
		'layouthub-global', 
		$upload_dir['baseurl'].'/layouthub/global.js',
		array('jquery'),
		$is_global_js,
		true
	);
}

/*
* End theme settings
*/

if (!$is_editor && isset($lh_meta)) {
	
	$modified_time = get_post_meta( $page_id, 'layouthub-time', true);
	$lh_meta = urldecode($lh_meta);
	
	if (is_file($lh_path.$lh_meta.DS.'index.php')) {
		
		$lh_layout = $lh_path.$lh_meta.DS.'index.php';
		
		if (isset($_POST['layouthub_router']) && $_POST['layouthub_router'] == 'ajax') {
			include_once($lh_layout);
			exit;
		}
		
	}
		
	if (is_file($lh_path.$lh_meta.DS.'style.css')) {
		wp_enqueue_style(
			'layouthub-pages', 
			$upload_dir['baseurl'].'/layouthub/'.str_replace(DS, '/', $lh_meta).'/style.css',
			array(),
			$modified_time
		);
	}
	
	if (is_file($lh_path.$lh_meta.DS.'script.js')) {
		wp_enqueue_script(
			'layouthub-pages', 
			$upload_dir['baseurl'].'/layouthub/'.str_replace(DS, '/', $lh_meta).'/script.js',
			array('jquery'),
			$modified_time,
			true
		);
	}
	
	if (
		isset($_POST['action']) &&
		$_POST['action'] == 'layouthub_section_ajax'
	) {
		
		unset($_POST['action']);
		
		$header_meta = get_option('layouthub-header');
		$footer_meta = get_option('layouthub-footer');
		
		if ($header_meta && is_file($lh_path.urldecode($header_meta).DS.'ajax.php'))
			require_once($lh_path.urldecode($header_meta).DS.'ajax.php');
		
		if (is_file($lh_path.$lh_meta.DS.'ajax.php'))
			require_once($lh_path.$lh_meta.DS.'ajax.php');
	
		if ($footer_meta && is_file($lh_path.urldecode($footer_meta).DS.'ajax.php'))
			require_once($lh_path.urldecode($footer_meta).DS.'ajax.php');
			
		exit;
			
	}
	
}

if (
	(isset($is_editor) && $is_editor === true) ||
	!empty($lh_layout)
) {
	add_action('wp_head', function() {
		echo '<style type="text/css">
				body .site {margin: 0px;}
				body .site-content {padding: 0px;}
				body .site-inner{max-width: 100%;}
				body:not(.custom-background-image).admin-bar:before,
				'.(isset($_GET['editor']) && $_GET['editor'] == 'true' ? '#wpadminbar,' : '').'
				body:not(.custom-background-image).admin-bar:after{
					display: none !important;
				}
		</style>';
	});
}

if (!function_exists('hub_lang')) {
	function hub_lang($text = '') {
		return __($text, 'layouthub');
	}
}

get_header(); 

if ($is_editor) {
	echo '<div id="layouthub-sections"><!--LayoutHub-Workspace--></div>';
} else if (
	!empty($lh_layout)
) {
    echo '<div id="layouthub-sections">';
    include_once($lh_layout);
    echo '</div>';
} else {
    
	echo '<div id="container"><main id="content-full">';
	
    if ( have_posts() ) : 
    	while ( have_posts() ) : the_post();
			the_content();
		endwhile; 
	endif;
	
    echo '</main></div>';
    
}
	    
get_footer(); 

?><!--This page layout is provided by LayoutHub.com-->