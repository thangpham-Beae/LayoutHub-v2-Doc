[
    {
        name: 'my_color',
        label: 'Select color',
        type: 'color_picker',
        value: 'red'
    }
]