[
    {
        name: 'size',
        label: 'Number field',
        type: 'number',
        value: 15,
        options: {
	        units: [ 'px', '%', 'rem']
        }
    }
]