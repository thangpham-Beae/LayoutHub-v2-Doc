[
    {
        name: 'content',
        label: 'Content',
        type: 'editor',
        value: '<p>The default value</p>'
    }
]