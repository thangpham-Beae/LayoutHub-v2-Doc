[
    {
        name: 'img',
        label: 'Single image',
        type: 'single_image',
        value: {
	        src: '%URL%thumbnail.jpg',
	        alt: 'Call to action',
	        class: 'hub-img'
        }
    }
]