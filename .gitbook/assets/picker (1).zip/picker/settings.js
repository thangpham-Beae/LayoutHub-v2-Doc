[
    {
        name: 'menu',
        label: 'Select menu',
        type: 'picker',
        value: '',
        "options": {
            "button_text": 'Browse menu',
            "multiple": false,
            "search": true,
            "type": 'menu',
            "title": 'Menu',
            "layout": 'list',
            "default": 'main-menu'
        }
    }
]