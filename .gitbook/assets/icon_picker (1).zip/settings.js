[
    {
        name: 'my_icon',
        label: 'Select icon',
        type: 'icon_picker',
        value: 'fa fa-star',
        options: {
	        source: '%URL%assets/fonts/fa-solid.css',
	        ext_class: 'fa'
        }
    }
]