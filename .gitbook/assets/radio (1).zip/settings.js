[
    {
        name: 'items',
        label: 'Select item',
        type: 'radio',
        value: 'two',
        options: {
	        'one': 'Value 1',
	        'two': 'Value 2',
	        'three': 'Value 3'
        }
    }
]