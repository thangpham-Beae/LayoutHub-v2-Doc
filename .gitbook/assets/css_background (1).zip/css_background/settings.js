[
    {
        name: 'my_bg',
        label: 'Set background',
        type: 'css_background',
        value: {
	        color: '#14C39B',
	        image: '%URL%thumbnail.jpg',
	        position: 'center center',
	        repeat: 'no-repeat',
	        size: 'contain'
        }
    }
]