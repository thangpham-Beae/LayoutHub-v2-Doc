[
    {
        name: 'title',
        label: 'My Title',
        type: 'text',
        value: 'Default '
    }
]