[
    {
        name: 'size',
        label: 'Adjust font size',
        type: 'number_slider',
        value: '15px',
        options: {
	        min: 10,
	        max: 30,
	        unit: 'px',
	        range: false,
	        show_input: false,
			step: 0,
			ratio: 1
        }
    }
]