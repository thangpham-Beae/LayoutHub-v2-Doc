[
    {
        name: 'text',
        label: 'My Text',
        type: 'textarea',
        placeholder: 'Placeholder text',
        value: 'Default content of textarea'
    }
]