[
	{
		'tab_name': 'Settings',
		'settings': [
			{
		        name: 'pt_subtitle',
		        label: 'Sub title',
		        value: 'Quick links',
		        type: 'text'
		    },
		    {
		        name: 'pt_title',
		        label: 'Title',
		        value: 'Talk about your business',
		        type: 'text'
		    },
		    {
		        name: 'pt_description',
		        label: 'Description',
		        value: 'Share store details, promotions, or brand content with your customers.',
		        type: 'textarea'
		    }
		]
	},
	{
		'tab_name': 'Pricing items',
		'settings': [
            {
                name: 'pt_table_title',
                label: 'Table title',
                value: 'Pricing Table',
                type: 'text'
            },
		    {
		        name: 'pt_items',
		        label: 'Price table items',
		        type: 'group',
		        value: [
		            {
		                pi_title: "BASIC",
                        pi_features: "Privacy\n30gb Storage\nFree domain",
                        pi_price: '200',
		                pi_button_text: 'Buy now',
		                pi_button_url: '#button',
						pi_active: 'no'
		            },
                    {
                        pi_title: "ADVANCED",
                        pi_features: "Privacy\nFree domain\n30gb Storage\nSupport",
                        pi_price: '300',
                        pi_button_text: 'Buy now',
                        pi_button_url: '#button',
                        pi_active: 'yes'
                    },
                    {
                        pi_title: "PRO",
                        pi_features: "Privacy\n30gb Storage\nFree domain\nSupport\nNotifications",
                        pi_price: '400',
                        pi_button_text: 'Buy now',
                        pi_button_url: '#button',
                        pi_active: 'no'
                    }
		        ],
		        options: {
		            add_text: 'Add new item'
		        },
		        params: [
		            {
		                name: 'pi_title',
		                type: 'text',
		                label: 'Title'
		            },
                    {
                        name: 'pi_price',
                        type: 'text',
                        label: 'Price'
                    },
                    {
                        name: 'pi_features',
                        type: 'textarea',
                        label: 'Features'
                    },
		            {
		                name: 'pi_button_text',
		                type: 'text',
		                label: 'Button label'
		            },
		            {
		                name: 'pi_button_url',
		                type: 'text',
		                label: 'Button URL'
		            },
                    {
                        name: 'pi_active',
                        type: 'toggle',
                        label: 'Active',
						value: 'no'
                    }
		        ]
		    }
		]
	}
]