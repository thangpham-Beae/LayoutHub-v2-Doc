[
    {
        name  : 'tm_subtitle',
        label : 'Sub title',
        type  : 'text',
        value: 'Quick links',
    },
    {
        name  : 'tm_title',
        label : 'Title',
        type  : 'text',
        value: 'Talk about your business',
    },
    {
        name  : 'tm_description',
        label : 'Description',
        type  : 'textarea',
        value: 'Share store details, promotions, or brand content with your customers.',
    },
    {
        name  : 'tm_column',
        label : 'Items per row',
        type  : 'dropdown',
        value: 'lh-col-md-6',
        options : {
            'lh-col-md-12' : '1',
            'lh-col-md-6' : '2'
        }
    },
    {
        name: 'tm_items',
        label: 'Team Member Items',
        type: 'group',
        value: [
            {
                ti_name: 'Kevin Appelbaum',
                ti_position: 'Co-founder & Ceo',
                ti_avatar: '%URL%assets/images/team_member_1.png',
                ti_description: 'Each of her former place of work it has best productivity by orders of magnitude higher.',
                ti_facebook: '#face',
                ti_twitter: '#twitter',
                ti_instagram: '#instagram',
            },
            {
                ti_name: 'Isak Johannesson',
                ti_position: 'Design Leader',
                ti_avatar: '%URL%assets/images/team_member_2.png',
                ti_description: 'Each of her former place of work it has best productivity by orders of magnitude higher.',
                ti_facebook: '#face1',
                ti_twitter: '#twitter1',
                ti_instagram: '#instagram1',
            },
            {
                ti_name: 'Adhraaa Al Azimi',
                ti_position: 'Marketing Leder',
                ti_avatar: '%URL%assets/images/team_member_3.png',
                ti_description: 'Each of her former place of work it has best productivity by orders of magnitude higher.',
                ti_facebook: '#face2',
                ti_twitter: '#twitter2',
                ti_instagram: '#instagram2',
            },
            {
                ti_name: 'Martina Brito',
                ti_position: 'Ui/Ux Designer',
                ti_avatar: '%URL%assets/images/team_member_4.png',
                ti_description: 'Each of her former place of work it has best productivity by orders of magnitude higher.',
                ti_facebook: '#face3',
                ti_twitter: '#twitter3',
                ti_instagram: '#instagram3',
            },
        ],
        options: {
            add_text: 'Add new item'
        },
        params: [
            {
                name: 'ti_name',
                type: 'text',
                label: 'Name'
            },
            {
                name: 'ti_position',
                type: 'text',
                label: 'Position'
            },
            {
                name: 'ti_avatar',
                type: 'image',
                label: 'Avatar'
            },
            {
                name: 'ti_description',
                type: 'textarea',
                label: 'Description'
            },
            {
                name: 'ti_facebook',
                type: 'text',
                label: 'Facebook'
            },
            {
                name: 'ti_twitter',
                type: 'text',
                label: 'Twitter'
            },
            {
                name: 'ti_instagram',
                type: 'text',
                label: 'Instagram'
            }
        ]
    },
]