[
    {
        name: 'items',
        label: 'Select items',
        type: 'checkbox',
        value: 'two',
        options: {
	        'one': 'Value 1',
	        'two': 'Value 2',
	        'three': 'Value 3'
        }
    }
]