[
    {
        name: 'toggle',
        label: 'Change toggle',
        type: 'toggle',
        value: 'yes'
    }
]